# ECHO SHIFT

Echo Shift to kompletna gra platformowo-logiczna 2D na Unity 6. Wspinasz się przez szyb wentylacyjny, przeskakujesz między dwiema fazami świata i uciekasz przed lawą w kampanii liczącej 30 etapów.

## Uruchomienie

1. Rozpakuj folder projektu i otwórz `EchoShiftUnity` w Unity Hub.
2. Użyj Unity `6000.6.8f1` lub nowszej wersji Unity 6.
3. Otwórz `Assets/Scenes/EchoShift.unity` i naciśnij Play.
4. Jeśli scena nie istnieje, wybierz z menu Unity `Echo Shift > Create Demo Scene`.

Projekt korzysta z wbudowanych kształtów i sprite'ów rysowanych w C# podczas uruchomienia. Nie wymaga zewnętrznych pakietów graficznych ani plików audio. Sterowanie klawiaturą i UI korzystają z pakietu Input System 1.20.1 oraz UGUI; Unity pobiera je z zależności projektu.

## Sterowanie

- `A` / `D` lub strzałki: ruch
- `Spacja`, `W` lub strzałka w górę: skok (przytrzymaj, by skoczyć wyżej)
- `Q`: aktywuj Echo na 3,8 sekundy; Q ponownie wraca do Materii (zmieniaj fazę w locie)
- `R`: restart bieżącego poziomu
- `Esc`: pauza / powrót do gry

Echo od razu odsłania i uruchamia fioletowe platformy. Rdzenie niewłaściwej fazy są widoczne jako przygaszone podpowiedzi, a można je zebrać tylko w wymaganej fazie. HUD pokazuje liczbę rdzeni i postęp na osobnych, świetlnych znacznikach. Aby zmienić fazę bez utraty podłoża, skocz i naciśnij Q w locie. Echo nie zużywa energii, ale wygasa po 3,8 sekundy. Poza tym w Echo postać nabiera jasnoniebieskiego blasku, a przejściu towarzyszy fala świetlna i krótki dźwięk syntezatora.

## Samouczek i poziomy

Gra zaczyna się samouczkiem, który uczy ruchu, skoku, zmiany fazy i zbierania rdzeni. Menu wyboru ma przewijaną listę wszystkich 30 etapów. Można od razu rozpocząć dowolny z nich, a ukończone poziomy są zapisywane i oznaczane złotą gwiazdką.

1. **Samouczek** — bezpieczna nauka ruchu, skoku, Echa i zbierania rdzeni.
2. **Poziomy 01–05** — od szerokich platform po pierwsze wąskie i ruchome przeszkody.
3. **Poziomy 06–11** — dłuższe trasy, coraz szybsza lawa, więcej rdzeni i ruchomych platform.
4. **Poziomy 12–21** — trudne skoki, węższe podesty, więcej zmian faz i większe tempo lawy.
5. **Poziomy 22–29** — bardzo trudne finałowe etapy z maksymalnie ośmioma rdzeniami i wieloma ruchomymi platformami.

Na każdym poziomie lawa zaczyna się poniżej komory i stopniowo wspina ku wyjściu. Restart przywraca położenie lawy, platformy, rdzenie i postać. Podpowiedzi mają duży kontrastowy panel; postać ma animacje biegu, skoku, spadania, lądowania i oddechu.

Lawa jest podawana do szybu przez stalowe kanały z kolankami i rozgrzanymi rdzeniami przepływu. Z wylotów spływają falujące, pulsujące strugi z jasnym, płynnym rdzeniem. Krople opadają wzdłuż strug, rozpryskują się i tworzą kręgi na powierzchni. Tafla faluje, mieni się i wypuszcza bąble oraz żar; wraz ze wzrostem poziomu zalewa rury.

Platformy tej samej fazy są układane naprzemiennie po lewej i prawej stronie szybu, bez pionowych kolumn blokujących drogę. Mają też kolizję jednostronną: postać może przebić się przez nie od spodu, a wylądować na nich od góry. Na platformach ruchomych postać jedzie razem z ich ruchem.

## Struktura kodu

- `EchoShiftGame.cs` — stany gry, zmiany faz, interfejs, menu, pauza, przejścia i syntezowane efekty dźwiękowe.
- `PlayerController2D.cs` — ruch, skok, wykrywanie podłoża i animacje postaci.
- `PhasePlatform.cs` — widoczność, kolizja i ruch platform zależny od fazy.
- `EchoLevelBuilder.cs` — budowanie samouczka i 29 poziomów kampanii o rosnącej trudności, komory, platform, rdzeni i wyjścia.
- `EchoWorldObjects.cs` — animowana lawa i rury, rdzenie, brama, efekt fali.
- `EchoArt.cs` — sprite'y postaci, poświaty, kryształów i platform tworzone proceduralnie.
- `Assets/Editor/EchoShiftSceneBuilder.cs` — tworzenie sceny startowej z menu Unity.

Główne pliki logiki gry znajdują się w `Assets/Scripts`.
