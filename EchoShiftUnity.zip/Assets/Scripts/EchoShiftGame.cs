using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;

public class EchoShiftGame : MonoBehaviour
{
    public enum WorldPhase { Material, Echo }
    public enum GameState { Title, Playing, Paused, Dead, Victory }

    public static EchoShiftGame Instance { get; private set; }
    public GameState State { get; private set; }
    public WorldPhase CurrentPhase { get; private set; }
    public PlayerController2D Player { get; private set; }
    public bool HasAllCores { get { return level != null && coresCollected >= level.requiredCores; } }

    const float EchoDuration = 3.8f;
    const string LevelCompletionKeyPrefix = "EchoShift.LevelComplete.";
    Camera gameCamera;
    AudioSource audioSource;
    AudioClip phaseClip, jumpClip, coreClip, deathClip, winClip;
    Transform levelRoot;
    EchoLevelBuilder.BuiltLevel level;
    PhasePlatform[] platforms = Array.Empty<PhasePlatform>();
    System.Collections.Generic.List<PhasePlatform> phaseList = new System.Collections.Generic.List<PhasePlatform>();
    int levelIndex, coresCollected;
    int tutorialHintStage;
    float echoRemaining, levelTime, totalTime, hintTimer, bannerTimer, cameraImpulse;
    Vector3 lastPlayerPosition;

    Canvas canvas;
    GameObject hud, titleScreen, controlsScreen, levelSelectScreen, pauseScreen, resultScreen, hintBox, bannerBox;
    Text titleText, subtitleText, levelTitleText, levelSubtitleText, phaseText, coreText, lavaText, elapsedText, hintText, bannerText;
    Image echoFill, progressFill;
    Image[] corePips = Array.Empty<Image>();
    Button[] levelSelectButtons = Array.Empty<Button>();
    Text[] levelSelectStars = Array.Empty<Text>();
    ScrollRect levelSelectScroll;

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        Application.targetFrameRate = 120;
        QualitySettings.antiAliasing = Mathf.Max(QualitySettings.antiAliasing, 4);
        gameCamera = GetComponent<Camera>();
        if (gameCamera == null) gameCamera = Camera.main;
        if (gameCamera == null) gameCamera = new GameObject("Main Camera").AddComponent<Camera>();
        gameCamera.orthographic = true; gameCamera.orthographicSize = 5.3f; gameCamera.backgroundColor = new Color(.018f, .026f, .06f);
        gameCamera.allowMSAA = true; gameCamera.allowHDR = true;
        if (gameCamera.GetComponent<AudioListener>() == null) gameCamera.gameObject.AddComponent<AudioListener>();
        audioSource = gameCamera.GetComponent<AudioSource>();
        if (audioSource == null) audioSource = gameCamera.gameObject.AddComponent<AudioSource>();
        audioSource.spatialBlend = 0; audioSource.playOnAwake = false; audioSource.volume = .72f;
        phaseClip = Tone(440f, .32f, true); jumpClip = Tone(210f, .11f, false); coreClip = Tone(710f, .3f, true); deathClip = Tone(115f, .72f, false); winClip = Tone(560f, .8f, true);
        BuildUI(); ShowTitle();
    }

    void OnDestroy() { if (Instance == this) Instance = null; }

    void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (State == GameState.Playing)
        {
            levelTime += Time.deltaTime; totalTime += Time.deltaTime;
            if (keyboard != null && keyboard.qKey.wasPressedThisFrame) ToggleEcho();
            if (keyboard != null && keyboard.rKey.wasPressedThisFrame) RestartLevel();
            if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame) Pause();
            if (CurrentPhase == WorldPhase.Echo)
            {
                echoRemaining -= Time.deltaTime;
                if (echoRemaining <= 0) SetPhase(WorldPhase.Material, true);
            }
        }
        else if (State == GameState.Paused && keyboard != null && keyboard.escapeKey.wasPressedThisFrame) Resume();
        else if (State == GameState.Paused && keyboard != null && keyboard.rKey.wasPressedThisFrame) RestartLevel();
        else if (State == GameState.Dead && keyboard != null && keyboard.rKey.wasPressedThisFrame) RestartLevel();
        else if (State == GameState.Victory && keyboard != null && keyboard.rKey.wasPressedThisFrame) BeginGame();

        UpdateTutorialHints();
        if (hintTimer > 0)
        {
            hintTimer -= Time.unscaledDeltaTime;
            if (hintTimer <= 0 && hintBox != null) hintBox.SetActive(false);
            else if (hintBox != null) hintBox.transform.localScale = Vector3.one * Mathf.Lerp(.94f, 1f, Mathf.SmoothStep(0, 1, Mathf.Clamp01((2.4f - hintTimer) / .18f)));
        }
        if (bannerTimer > 0)
        {
            bannerTimer -= Time.unscaledDeltaTime;
            if (bannerTimer <= 0 && bannerBox != null) bannerBox.SetActive(false);
            else if (bannerBox != null) bannerBox.transform.localScale = Vector3.one * Mathf.Lerp(.96f, 1f, Mathf.SmoothStep(0, 1, Mathf.Clamp01((3.4f - bannerTimer) / .2f)));
        }
        if (cameraImpulse > 0) cameraImpulse = Mathf.Max(0, cameraImpulse - Time.unscaledDeltaTime * 2.8f);
        UpdateHud();
    }

    void LateUpdate()
    {
        if (gameCamera == null || Player == null || level == null) return;
        Vector3 target = gameCamera.transform.position;
        if (State == GameState.Playing || State == GameState.Paused)
        {
            float half = gameCamera.orthographicSize;
            float wantedY = Mathf.Clamp(Player.transform.position.y + .75f, half - .4f, Mathf.Max(half - .4f, level.roomHeight - half + 1f));
            target.y = Mathf.Lerp(target.y, wantedY, 1f - Mathf.Exp(-4.5f * Time.unscaledDeltaTime));
        }
        Vector2 shake = cameraImpulse > 0 ? UnityEngine.Random.insideUnitCircle * cameraImpulse * .15f : Vector2.zero;
        gameCamera.transform.position = new Vector3(target.x + shake.x, target.y + shake.y, -10f);
    }

    public void RegisterPlatform(PhasePlatform platform) { phaseList.Add(platform); }
    public void PlayJumpSound() { if (audioSource != null && jumpClip != null) audioSource.PlayOneShot(jumpClip, .22f); }

    public void BeginGame()
    {
        Time.timeScale = 1; totalTime = 0; levelIndex = 0; LoadLevel(0, false);
    }

    void LoadLevel(int index, bool announce)
    {
        Time.timeScale = 1;
        if (levelRoot != null) Destroy(levelRoot.gameObject);
        levelRoot = new GameObject("Level " + (index + 1).ToString("00") + " Runtime").transform;
        phaseList.Clear(); platforms = Array.Empty<PhasePlatform>(); Player = null;
        levelIndex = index; coresCollected = 0; levelTime = 0; echoRemaining = 0; CurrentPhase = WorldPhase.Material;
        tutorialHintStage = index == 0 ? 1 : 0; hintTimer = 0; bannerTimer = 0;
        level = EchoLevelBuilder.Build(this, levelRoot, index);
        Player = level.player;
        platforms = phaseList.ToArray();
        foreach (var p in platforms) if (p != null) p.SetActivePhase(CurrentPhase);
        gameCamera.transform.position = new Vector3(0, 5.3f, -10);
        State = GameState.Playing;
        titleScreen.SetActive(false); controlsScreen.SetActive(false); levelSelectScreen.SetActive(false); pauseScreen.SetActive(false); resultScreen.SetActive(false);
        hud.SetActive(true);
        hintBox.SetActive(false); bannerBox.SetActive(false);
        if (index == 0)
        {
            ShowBanner("SAMOUCZEK  •  Naucz się ruchu, skoku i fazy Echa", 3.4f);
            ShowHint("KROK 1/4  •  A/D lub strzałki: ruch. Spacja: skok.");
        }
        else if (announce) ShowBanner(level.title + "  •  " + level.subtitle, 3.4f);
        UpdateHud();
    }

    public void ToggleEcho()
    {
        if (State != GameState.Playing) return;
        if (Player != null && Player.IsGrounded)
        {
            ShowHint("Najpierw skocz SPACJĄ, a w locie naciśnij Q, by zmienić fazę i zebrać rdzeń.");
            return;
        }
        if (CurrentPhase == WorldPhase.Echo) SetPhase(WorldPhase.Material, false);
        else { echoRemaining = EchoDuration; SetPhase(WorldPhase.Echo, false); }
    }

    void UpdateTutorialHints()
    {
        if (levelIndex != 0 || State != GameState.Playing || Player == null) return;
        float y = Player.transform.position.y;
        if (tutorialHintStage == 1 && y >= 2.9f)
        {
            tutorialHintStage = 2;
            ShowHint("KROK 2/4  •  Fioletowa platforma: skocz i naciśnij Q w locie.");
        }
        else if (tutorialHintStage == 2 && CurrentPhase == WorldPhase.Echo)
        {
            tutorialHintStage = 3;
            ShowHint("KROK 3/4  •  Będąc w Echo, dotknij fioletowego rdzenia, aby go zebrać.");
        }
        else if (tutorialHintStage == 3 && coresCollected >= level.requiredCores)
        {
            tutorialHintStage = 4;
            ShowHint("KROK 4/4  •  Rdzeń zebrany! Wspinaj się do portalu, zanim dotrze lawa.");
        }
        else if (tutorialHintStage == 4 && y >= 9.5f)
        {
            tutorialHintStage = 5;
            ShowHint("Portal jest u góry. R restartuje planszę, jeśli chcesz spróbować ponownie.");
        }
    }

    void SetPhase(WorldPhase phase, bool expired)
    {
        if (CurrentPhase == phase) return;
        CurrentPhase = phase;
        foreach (var p in platforms) if (p != null) p.SetActivePhase(phase);
        if (Player != null) Player.SetEchoLook(phase == WorldPhase.Echo);
        Vector3 at = Player != null ? Player.transform.position : Vector3.zero;
        var burst = new GameObject("Phase Shift Ripple"); burst.transform.position = at + new Vector3(0, .45f, -.4f); burst.AddComponent<EchoBurst>().Initialize(phase == WorldPhase.Echo ? new Color(.3f, .76f, 1f, .95f) : new Color(1f, .54f, .3f, .9f), .8f, .5f);
        cameraImpulse = .9f;
        if (audioSource != null && phaseClip != null) audioSource.PlayOneShot(phaseClip, .5f);
        if (phase == WorldPhase.Echo) ShowHint("Faza Echa uruchamia fioletowe platformy i rdzenie.");
        if (phase == WorldPhase.Material && expired) ShowHint("Faza Echa wygasła. Naciśnij Q, by użyć ponownie.");
        UpdateHud();
    }

    public void RestartLevel()
    {
        if (level != null) LoadLevel(levelIndex, true);
        else BeginGame();
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        State = GameState.Paused; Time.timeScale = 0; pauseScreen.SetActive(true);
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        State = GameState.Playing; Time.timeScale = 1; pauseScreen.SetActive(false);
    }

    public void PlayerCaughtByLava()
    {
        if (State != GameState.Playing) return;
        State = GameState.Dead; cameraImpulse = 1.2f;
        if (Player != null) { SpawnBurst(Player.transform.position, new Color(1f, .24f, .08f), 1.4f); Player.DisableMotion(); }
        if (audioSource != null && deathClip != null) audioSource.PlayOneShot(deathClip, .65f);
        Time.timeScale = 0; ShowResult("KONIEC PRÓBY", "Lawa dotarła do platform. Spróbuj jeszcze raz.", false);
    }

    public void ReachExit()
    {
        if (State != GameState.Playing) return;
        MarkLevelComplete(levelIndex);
        if (levelIndex + 1 < EchoLevelBuilder.Count)
        {
            LoadLevel(levelIndex + 1, true);
            if (audioSource != null && coreClip != null) audioSource.PlayOneShot(coreClip, .5f);
        }
        else
        {
            State = GameState.Victory; Time.timeScale = 0;
            if (audioSource != null && winClip != null) audioSource.PlayOneShot(winClip, .75f);
            ShowResult("SZYB ECHA ZAMKNIĘTY", "Udało Ci się wydostać. Czas: " + FormatTime(totalTime) + ".", true);
        }
    }

    public void CollectCore(Vector3 position)
    {
        coresCollected++;
        SpawnBurst(position, new Color(.22f, .9f, 1f), .8f);
        if (audioSource != null && coreClip != null) audioSource.PlayOneShot(coreClip, .58f);
        ShowHint("Rdzeń rezonansu zebrany: " + coresCollected + " / " + level.requiredCores);
        UpdateHud();
    }

    public void ShowHint(string message)
    {
        if (hintText == null) return;
        hintText.text = message; hintBox.SetActive(true); hintBox.transform.localScale = Vector3.one * .94f; hintTimer = 2.4f;
    }

    void ShowBanner(string message, float duration)
    {
        if (bannerText == null) return;
        bannerText.text = message; bannerBox.SetActive(true); bannerBox.transform.localScale = Vector3.one * .96f; bannerTimer = duration;
    }

    void SpawnBurst(Vector3 position, Color color, float size)
    {
        var burst = new GameObject("Echo Particle Ripple"); burst.transform.position = position; burst.AddComponent<EchoBurst>().Initialize(color, size, .58f);
    }

    void ShowTitle()
    {
        Time.timeScale = levelRoot == null ? 1 : 0; State = GameState.Title; hud.SetActive(false); titleScreen.SetActive(true);
        controlsScreen.SetActive(false); levelSelectScreen.SetActive(false); pauseScreen.SetActive(false); resultScreen.SetActive(false);
    }

    void ShowControls() { titleScreen.SetActive(false); controlsScreen.SetActive(true); }
    void ShowPauseMenu() { titleScreen.SetActive(false); pauseScreen.SetActive(true); }

    void ShowLevelSelect()
    {
        titleScreen.SetActive(false); controlsScreen.SetActive(false); levelSelectScreen.SetActive(true);
        if (levelSelectScroll != null) levelSelectScroll.verticalNormalizedPosition = 1f;
        RefreshLevelSelectStars();
    }

    void SelectLevel(int index)
    {
        totalTime = 0f;
        LoadLevel(index, true);
    }

    void MarkLevelComplete(int index)
    {
        PlayerPrefs.SetInt(LevelCompletionKeyPrefix + index, 1);
        PlayerPrefs.Save();
        RefreshLevelSelectStars();
    }

    void RefreshLevelSelectStars()
    {
        if (levelSelectStars == null) return;
        for (int i = 0; i < levelSelectStars.Length; i++)
        {
            bool complete = PlayerPrefs.GetInt(LevelCompletionKeyPrefix + i, 0) == 1;
            levelSelectStars[i].text = complete ? "★" : "";
            if (levelSelectButtons != null && i < levelSelectButtons.Length && levelSelectButtons[i] != null)
            {
                var colors = levelSelectButtons[i].colors;
                colors.normalColor = complete ? new Color(.16f, .28f, .31f) : new Color(.095f, .16f, .26f);
                levelSelectButtons[i].colors = colors;
            }
        }
    }

    void ShowResult(string heading, string body, bool victory)
    {
        hud.SetActive(false); resultScreen.SetActive(true); titleText.text = heading; subtitleText.text = body;
        var buttons = resultScreen.GetComponentsInChildren<Button>(true);
        if (buttons.Length > 0) buttons[0].GetComponentInChildren<Text>().text = victory ? "ZAGRAJ PONOWNIE" : "SPRÓBUJ PONOWNIE";
    }

    void UpdateHud()
    {
        if (level == null || hud == null) return;
        levelTitleText.text = level.title;
        levelSubtitleText.text = level.subtitle;
        coreText.text = level.requiredCores > 0 ? "RDZENIE  " + coresCollected + " / " + level.requiredCores : "RDZENIE  —";
        for (int i = 0; i < corePips.Length; i++)
        {
            corePips[i].gameObject.SetActive(i < level.requiredCores);
            bool collected = i < coresCollected;
            corePips[i].color = collected ? new Color(.42f, 1f, .78f, 1f) : new Color(.76f, .48f, 1f, .9f);
            corePips[i].transform.localScale = collected ? Vector3.one * .82f : Vector3.one;
        }
        if (CurrentPhase == WorldPhase.Echo)
        {
            phaseText.text = "ECHO  " + Mathf.Max(0, echoRemaining).ToString("0.0") + "s";
            echoFill.fillAmount = Mathf.Clamp01(echoRemaining / EchoDuration);
            echoFill.color = new Color(.39f, .74f, 1f);
        }
        else
        {
            phaseText.text = "MATERIA  /  Q = ECHO"; echoFill.fillAmount = 0;
            echoFill.color = new Color(.39f, .74f, 1f);
        }
        elapsedText.text = "CZAS  " + FormatTime(levelTime);
        lavaText.text = "LAWINA MAGMY  ↑  " + level.lavaSpeed.ToString("0.00") + " m/s";
        if (progressFill != null && Player != null) progressFill.fillAmount = Mathf.Clamp01(Player.transform.position.y / Mathf.Max(1, level.exitY));
    }

    static string FormatTime(float seconds)
    {
        int s = Mathf.Max(0, Mathf.FloorToInt(seconds));
        return (s / 60).ToString("00") + ":" + (s % 60).ToString("00");
    }

    static AudioClip Tone(float frequency, float duration, bool bright)
    {
        const int rate = 22050;
        int count = Mathf.CeilToInt(rate * duration);
        var samples = new float[count];
        for (int i = 0; i < count; i++)
        {
            float t = i / (float)rate;
            float envelope = Mathf.Exp(-t * (bright ? 4.2f : 5.8f)) * Mathf.Clamp01(t * 45f);
            float fundamental = Mathf.Sin(2f * Mathf.PI * frequency * t);
            float overtone = Mathf.Sin(2f * Mathf.PI * frequency * (bright ? 2.01f : .5f) * t) * (bright ? .34f : .18f);
            samples[i] = (fundamental + overtone) * envelope * .23f;
        }
        AudioClip clip = AudioClip.Create("Echo Synth " + frequency, count, 1, rate, false);
        clip.SetData(samples, 0); return clip;
    }

    void BuildUI()
    {
        var eventSystem = FindAnyObjectByType<EventSystem>();
        if (eventSystem == null)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
            DontDestroyOnLoad(es);
        }
        else
        {
            var legacyModule = eventSystem.GetComponent<StandaloneInputModule>();
            if (legacyModule != null) Destroy(legacyModule);
            if (eventSystem.GetComponent<InputSystemUIInputModule>() == null) eventSystem.gameObject.AddComponent<InputSystemUIInputModule>();
        }
        var canvasGo = new GameObject("Echo Shift UI", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvas = canvasGo.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay; canvas.sortingOrder = 100;
        var scaler = canvasGo.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution = new Vector2(1600, 900); scaler.matchWidthOrHeight = .7f;

        hud = new GameObject("HUD", typeof(RectTransform)); hud.transform.SetParent(canvas.transform, false);
        var hudRect = hud.GetComponent<RectTransform>(); Stretch(hudRect);
        var header = Panel("HUD Header", hud.transform, new Color(.025f, .045f, .09f, .9f), new Vector2(0, 1), new Vector2(1, 1), new Vector2(.5f, 1), Vector2.zero, new Vector2(0, 132));
        levelTitleText = Text("01 / ISKRA", header.transform, 30, FontStyle.Bold, new Color(.39f, .86f, 1f), TextAnchor.MiddleLeft, new Vector2(34, -30), new Vector2(540, 42));
        levelSubtitleText = Text("", header.transform, 18, FontStyle.Normal, new Color(.76f, .83f, .95f), TextAnchor.MiddleLeft, new Vector2(36, -76), new Vector2(720, 34));
        phaseText = Text("MATERIA  /  Q = ECHO", header.transform, 18, FontStyle.Bold, Color.white, TextAnchor.MiddleRight, new Vector2(-34, -34), new Vector2(350, 34));
        phaseText.rectTransform.anchorMin = new Vector2(1, 1); phaseText.rectTransform.anchorMax = new Vector2(1, 1); phaseText.rectTransform.pivot = new Vector2(1, .5f);
        var echoBar = CreateUIImage("Echo Timer Back", header.transform, new Color(.09f, .14f, .22f, 1), new Vector2(1, 1), new Vector2(1, 1), new Vector2(1, 1), new Vector2(-34, -72), new Vector2(300, 10));
        echoFill = CreateUIImage("Echo Timer", echoBar.transform, new Color(.39f, .74f, 1f), Vector2.zero, Vector2.one, new Vector2(0, .5f), Vector2.zero, Vector2.zero);
        echoFill.type = Image.Type.Filled; echoFill.fillMethod = Image.FillMethod.Horizontal; echoFill.fillOrigin = (int)Image.OriginHorizontal.Left;
        coreText = Text("RDZENIE  —", header.transform, 16, FontStyle.Bold, new Color(1f, .82f, .55f), TextAnchor.MiddleRight, new Vector2(-34, -104), new Vector2(164, 26));
        coreText.rectTransform.anchorMin = new Vector2(1, 1); coreText.rectTransform.anchorMax = new Vector2(1, 1); coreText.rectTransform.pivot = new Vector2(1, .5f);
        coreText.rectTransform.anchoredPosition = new Vector2(-34, -104);
        corePips = new Image[8];
        for (int i = 0; i < corePips.Length; i++)
        {
            var pip = CreateUIImage("Resonance Core Marker " + (i + 1), header.transform, new Color(.76f, .48f, 1f, .9f),
                new Vector2(1, 1), new Vector2(1, 1), new Vector2(.5f, .5f), new Vector2(-222 - i * 23, -104), new Vector2(13, 13));
            pip.sprite = EchoArt.White; pip.raycastTarget = false; pip.transform.localRotation = Quaternion.Euler(0, 0, 45);
            corePips[i] = pip;
        }
        elapsedText = Text("CZAS  00:00", header.transform, 16, FontStyle.Normal, new Color(.78f, .86f, .95f), TextAnchor.MiddleLeft, new Vector2(36, -106), new Vector2(180, 26));
        lavaText = Text("LAWINA MAGMY", header.transform, 16, FontStyle.Bold, new Color(1f, .62f, .39f), TextAnchor.MiddleCenter, new Vector2(0, -106), new Vector2(330, 26));
        progressFill = CreateUIImage("Climb Progress", hud.transform, new Color(.3f, .92f, 1f), new Vector2(0, .1f), new Vector2(0, .1f), new Vector2(0, 0), new Vector2(0, 0), new Vector2(5, 300));
        progressFill.type = Image.Type.Filled; progressFill.fillMethod = Image.FillMethod.Vertical; progressFill.fillOrigin = (int)Image.OriginVertical.Bottom;

        hintBox = Panel("Hint Chip", hud.transform, new Color(.015f, .055f, .11f, .98f), new Vector2(.5f, 0), new Vector2(.5f, 0), new Vector2(.5f, 0), new Vector2(0, 44), new Vector2(920, 78));
        hintText = Text("", hintBox.transform, 22, FontStyle.Bold, new Color(.94f, .98f, 1f), TextAnchor.MiddleCenter, Vector2.zero, new Vector2(880, 68));
        var hintShadow = hintText.gameObject.AddComponent<Shadow>(); hintShadow.effectColor = new Color(.04f, .38f, .68f, .9f); hintShadow.effectDistance = new Vector2(1.5f, -1.5f);
        bannerBox = Panel("Mission Banner", hud.transform, new Color(.015f, .045f, .095f, .97f), new Vector2(.5f, 1), new Vector2(.5f, 1), new Vector2(.5f, 1), new Vector2(0, -164), new Vector2(1120, 70));
        bannerText = Text("", bannerBox.transform, 24, FontStyle.Bold, new Color(.83f, .96f, 1f), TextAnchor.MiddleCenter, Vector2.zero, new Vector2(1080, 62));
        var bannerShadow = bannerText.gameObject.AddComponent<Shadow>(); bannerShadow.effectColor = new Color(.05f, .38f, .7f, .85f); bannerShadow.effectDistance = new Vector2(1.5f, -1.5f);
        bannerBox.SetActive(false);
        Text("A/D lub ←/→ ruch     SPACJA skok     Q Echo     R restart     ESC pauza", hud.transform, 15, FontStyle.Normal,
            new Color(.68f, .76f, .88f, .78f), TextAnchor.MiddleCenter, new Vector2(0, 12), new Vector2(1000, 26)).rectTransform.anchorMin = new Vector2(.5f, 0);

        titleScreen = Modal("Title Screen", new Color(.012f, .023f, .055f, .94f), canvas.transform);
        var titleHalo = CreateUIImage("Echo Title Halo", titleScreen.transform, new Color(.22f, .72f, 1f, .23f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(0, 15), new Vector2(720, 720));
        titleHalo.sprite = EchoArt.Ring; titleHalo.preserveAspect = true; titleHalo.raycastTarget = false;
        var titleCore = CreateUIImage("Echo Title Core", titleScreen.transform, new Color(.55f, .38f, 1f, .12f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(0, 15), new Vector2(470, 470));
        titleCore.sprite = EchoArt.Orb; titleCore.preserveAspect = true; titleCore.raycastTarget = false;
        var card = Panel("Title Card", titleScreen.transform, new Color(.035f, .064f, .12f, .96f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), Vector2.zero, new Vector2(690, 610));
        Text("ECHO SHIFT", card.transform, 58, FontStyle.Bold, new Color(.42f, .88f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 155), new Vector2(620, 90));
        Text("WSPINAJ SIĘ. ZMIENIAJ FAZĘ. UCIEKAJ PRZED LAWĄ.", card.transform, 18, FontStyle.Bold, new Color(.88f, .75f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 90), new Vector2(600, 38));
        Text("Najpierw samouczek, potem 29 coraz trudniejszych poziomów.\nEcho odsłania ukryte platformy przez 3,8 sekundy.", card.transform, 19, FontStyle.Normal, new Color(.86f, .91f, .98f), TextAnchor.MiddleCenter, new Vector2(0, 24), new Vector2(580, 70));
        MakeButton("GRAJ  •  SAMOUCZEK", card.transform, new Vector2(0, -64), new Vector2(330, 56), BeginGame, true);
        MakeButton("WYBIERZ POZIOM", card.transform, new Vector2(0, -132), new Vector2(330, 54), ShowLevelSelect, false);
        MakeButton("STEROWANIE", card.transform, new Vector2(0, -198), new Vector2(330, 52), ShowControls, false);
        Text("A/D ruch  •  SPACJA skok  •  Q w locie: Echo", card.transform, 15, FontStyle.Bold, new Color(.76f, .84f, .95f), TextAnchor.MiddleCenter, new Vector2(0, -264), new Vector2(560, 30));
        titleText = null; subtitleText = null;

        controlsScreen = Modal("Controls Screen", new Color(.012f, .023f, .055f, .94f), canvas.transform);
        var cc = Panel("Controls Card", controlsScreen.transform, new Color(.035f, .064f, .12f, .97f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), Vector2.zero, new Vector2(650, 530));
        Text("JAK GRAĆ", cc.transform, 38, FontStyle.Bold, new Color(.42f, .88f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 165), new Vector2(560, 65));
        Text("A / D lub strzałki     ruch w lewo i prawo\nSPACJA lub W     skok\nQ     aktywuj Echo na 3,8 sekundy\nR     restart poziomu     ESC     pauza\n\nSkocz, a potem naciśnij Q w locie.\nFioletowe rdzenie zbierzesz tylko w fazie Echa.\nEcho uruchamia fioletowe platformy. Uważaj na lawę!", cc.transform, 19, FontStyle.Normal, new Color(.84f, .9f, .97f), TextAnchor.MiddleCenter, new Vector2(0, -12), new Vector2(540, 310));
        MakeButton("WRÓĆ", cc.transform, new Vector2(0, -208), new Vector2(230, 48), () => { controlsScreen.SetActive(false); titleScreen.SetActive(true); }, false);

        levelSelectScreen = Modal("Level Select Screen", new Color(.012f, .023f, .055f, .97f), canvas.transform);
        var selectCard = Panel("Level Select Card", levelSelectScreen.transform, new Color(.035f, .064f, .12f, .98f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), Vector2.zero, new Vector2(860, 710));
        Text("WYBIERZ POZIOM", selectCard.transform, 42, FontStyle.Bold, new Color(.42f, .88f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 295), new Vector2(760, 60));
        Text("30 etapów od samouczka do bardzo trudnych. Przewijaj listę; złota gwiazdka oznacza ukończenie.", selectCard.transform, 17, FontStyle.Normal, new Color(.79f, .86f, .95f), TextAnchor.MiddleCenter, new Vector2(0, 252), new Vector2(760, 32));

        var viewportObject = new GameObject("Level List Viewport", typeof(RectTransform), typeof(Image), typeof(Mask));
        viewportObject.transform.SetParent(selectCard.transform, false);
        var viewportRect = viewportObject.GetComponent<RectTransform>();
        viewportRect.anchorMin = viewportRect.anchorMax = new Vector2(.5f, .5f);
        viewportRect.pivot = new Vector2(.5f, .5f);
        viewportRect.anchoredPosition = new Vector2(0, -16);
        viewportRect.sizeDelta = new Vector2(790, 470);
        var viewportImage = viewportObject.GetComponent<Image>();
        viewportImage.color = new Color(1f, 1f, 1f, .01f);
        viewportImage.raycastTarget = true;
        viewportObject.GetComponent<Mask>().showMaskGraphic = false;

        var contentObject = new GameObject("Level List Content", typeof(RectTransform));
        contentObject.transform.SetParent(viewportObject.transform, false);
        var contentRect = contentObject.GetComponent<RectTransform>();
        contentRect.anchorMin = new Vector2(0, 1); contentRect.anchorMax = new Vector2(1, 1);
        contentRect.pivot = new Vector2(.5f, 1);
        contentRect.anchoredPosition = Vector2.zero;
        contentRect.sizeDelta = new Vector2(0, EchoLevelBuilder.Count * 60f + 24f);
        levelSelectScroll = viewportObject.AddComponent<ScrollRect>();
        levelSelectScroll.content = contentRect; levelSelectScroll.viewport = viewportRect;
        levelSelectScroll.horizontal = false; levelSelectScroll.vertical = true;
        levelSelectScroll.movementType = ScrollRect.MovementType.Clamped;
        levelSelectScroll.scrollSensitivity = 45f; levelSelectScroll.decelerationRate = .12f;

        var scrollbarObject = new GameObject("Level List Scrollbar", typeof(RectTransform), typeof(Image), typeof(Scrollbar));
        scrollbarObject.transform.SetParent(selectCard.transform, false);
        var scrollbarRect = scrollbarObject.GetComponent<RectTransform>();
        scrollbarRect.anchorMin = scrollbarRect.anchorMax = new Vector2(.5f, .5f);
        scrollbarRect.pivot = new Vector2(.5f, .5f);
        scrollbarRect.anchoredPosition = new Vector2(407, -16);
        scrollbarRect.sizeDelta = new Vector2(12, 470);
        var scrollbarImage = scrollbarObject.GetComponent<Image>();
        scrollbarImage.color = new Color(.07f, .14f, .22f, .9f);
        var handleObject = new GameObject("Scrollbar Handle", typeof(RectTransform), typeof(Image));
        handleObject.transform.SetParent(scrollbarObject.transform, false);
        var handleRect = handleObject.GetComponent<RectTransform>();
        handleRect.anchorMin = Vector2.zero; handleRect.anchorMax = Vector2.one;
        handleRect.offsetMin = new Vector2(2, 2); handleRect.offsetMax = new Vector2(-2, -2);
        var handleImage = handleObject.GetComponent<Image>(); handleImage.color = new Color(.27f, .72f, .94f, .9f);
        var levelScrollbar = scrollbarObject.GetComponent<Scrollbar>();
        levelScrollbar.handleRect = handleRect; levelScrollbar.targetGraphic = handleImage;
        levelScrollbar.direction = Scrollbar.Direction.BottomToTop;
        levelSelectScroll.verticalScrollbar = levelScrollbar;
        levelSelectScroll.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;

        levelSelectButtons = new Button[EchoLevelBuilder.Count];
        levelSelectStars = new Text[EchoLevelBuilder.Count];
        for (int i = 0; i < EchoLevelBuilder.Count; i++)
        {
            int selectedIndex = i;
            float rowY = -14f - i * 60f;
            Button row = MakeButton(EchoLevelBuilder.TitleFor(i), contentObject.transform, new Vector2(0, rowY), new Vector2(750, 52), () => SelectLevel(selectedIndex), i == 0);
            RectTransform rowRect = row.GetComponent<RectTransform>();
            rowRect.anchorMin = rowRect.anchorMax = new Vector2(.5f, 1f);
            rowRect.pivot = new Vector2(.5f, 1f);
            rowRect.anchoredPosition = new Vector2(0, rowY);
            Text rowTitle = row.GetComponentInChildren<Text>();
            rowTitle.alignment = TextAnchor.MiddleLeft;
            rowTitle.rectTransform.anchorMin = rowTitle.rectTransform.anchorMax = new Vector2(0, .5f);
            rowTitle.rectTransform.pivot = new Vector2(0, .5f);
            rowTitle.rectTransform.anchoredPosition = new Vector2(22, 0);
            rowTitle.rectTransform.sizeDelta = new Vector2(400, 48);
            Text difficulty = Text(EchoLevelBuilder.DifficultyFor(i), row.transform, 14, FontStyle.Bold, new Color(.62f, .78f, .91f), TextAnchor.MiddleRight, new Vector2(205, 0), new Vector2(170, 40));
            difficulty.rectTransform.anchorMin = difficulty.rectTransform.anchorMax = new Vector2(1f, .5f);
            difficulty.rectTransform.pivot = new Vector2(1f, .5f);
            difficulty.rectTransform.anchoredPosition = new Vector2(-62, 0);
            Text star = Text("", row.transform, 32, FontStyle.Bold, new Color(1f, .78f, .2f), TextAnchor.MiddleCenter, new Vector2(325, 0), new Vector2(44, 48));
            star.rectTransform.anchorMin = star.rectTransform.anchorMax = new Vector2(1f, .5f);
            star.rectTransform.pivot = new Vector2(.5f, .5f);
            star.rectTransform.anchoredPosition = new Vector2(-28, 0);
            levelSelectButtons[i] = row;
            levelSelectStars[i] = star;
        }
        MakeButton("WRÓĆ DO MENU", selectCard.transform, new Vector2(0, -310), new Vector2(260, 48), () => { levelSelectScreen.SetActive(false); titleScreen.SetActive(true); }, false);
        RefreshLevelSelectStars();

        pauseScreen = Modal("Pause Screen", new Color(.012f, .023f, .055f, .84f), canvas.transform);
        var pc = Panel("Pause Card", pauseScreen.transform, new Color(.035f, .064f, .12f, .98f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), Vector2.zero, new Vector2(500, 430));
        Text("PAUZA", pc.transform, 44, FontStyle.Bold, new Color(.42f, .88f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 130), new Vector2(440, 65));
        MakeButton("WRÓĆ DO GRY", pc.transform, new Vector2(0, 52), new Vector2(300, 54), Resume, true);
        MakeButton("RESTARTUJ", pc.transform, new Vector2(0, -18), new Vector2(300, 52), RestartLevel, false);
        MakeButton("MENU", pc.transform, new Vector2(0, -88), new Vector2(300, 52), ShowTitle, false);

        resultScreen = Modal("Result Screen", new Color(.012f, .023f, .055f, .9f), canvas.transform);
        var rc = Panel("Result Card", resultScreen.transform, new Color(.035f, .064f, .12f, .98f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), new Vector2(.5f, .5f), Vector2.zero, new Vector2(620, 440));
        titleText = Text("", rc.transform, 38, FontStyle.Bold, new Color(.42f, .88f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 110), new Vector2(560, 80));
        subtitleText = Text("", rc.transform, 18, FontStyle.Normal, new Color(.78f, .85f, .93f), TextAnchor.MiddleCenter, new Vector2(0, 30), new Vector2(520, 70));
        MakeButton("SPRÓBUJ PONOWNIE", rc.transform, new Vector2(0, -68), new Vector2(340, 55), RestartLevel, true);
        MakeButton("MENU", rc.transform, new Vector2(0, -140), new Vector2(270, 50), ShowTitle, false);

        titleScreen.SetActive(true); controlsScreen.SetActive(false); levelSelectScreen.SetActive(false); pauseScreen.SetActive(false); resultScreen.SetActive(false); hud.SetActive(false);
    }

    static GameObject Modal(string name, Color color, Transform parent)
    {
        var panel = new GameObject(name, typeof(RectTransform), typeof(Image));
        panel.transform.SetParent(parent, false);
        var rect = panel.GetComponent<RectTransform>(); Stretch(rect);
        panel.GetComponent<Image>().color = color; panel.GetComponent<Image>().raycastTarget = true;
        return panel;
    }

    static GameObject Panel(string name, Transform parent, Color color, Vector2 min, Vector2 max, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image)); go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>(); rt.anchorMin = min; rt.anchorMax = max; rt.pivot = pivot; rt.anchoredPosition = pos; rt.sizeDelta = size;
        go.GetComponent<Image>().color = color; return go;
    }

    static Image CreateUIImage(string name, Transform parent, Color color, Vector2 min, Vector2 max, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image)); go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>(); rt.anchorMin = min; rt.anchorMax = max; rt.pivot = pivot; rt.anchoredPosition = pos; rt.sizeDelta = size;
        var image = go.GetComponent<Image>(); image.color = color; return image;
    }

    static Text Text(string value, Transform parent, int size, FontStyle style, Color color, TextAnchor align, Vector2 pos, Vector2 dimensions)
    {
        var go = new GameObject(value.Length > 22 ? "Label" : value, typeof(RectTransform), typeof(Text)); go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>(); rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.pivot = new Vector2(.5f, .5f); rt.anchoredPosition = pos; rt.sizeDelta = dimensions;
        var label = go.GetComponent<Text>(); label.text = value; label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); label.fontSize = size; label.fontStyle = style;
        label.color = color; label.alignment = align; label.horizontalOverflow = HorizontalWrapMode.Wrap; label.verticalOverflow = VerticalWrapMode.Overflow; label.raycastTarget = false;
        return label;
    }

    static Button MakeButton(string label, Transform parent, Vector2 pos, Vector2 size, UnityEngine.Events.UnityAction action, bool primary)
    {
        var go = new GameObject(label + " Button", typeof(RectTransform), typeof(Image), typeof(Button)); go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>(); rt.anchorMin = rt.anchorMax = new Vector2(.5f, .5f); rt.pivot = new Vector2(.5f, .5f); rt.anchoredPosition = pos; rt.sizeDelta = size;
        var image = go.GetComponent<Image>(); image.color = primary ? new Color(.11f, .52f, .65f) : new Color(.095f, .16f, .26f);
        var button = go.GetComponent<Button>(); button.targetGraphic = image; button.onClick.AddListener(action);
        var colors = button.colors; colors.normalColor = image.color; colors.highlightedColor = primary ? new Color(.2f, .72f, .84f) : new Color(.17f, .28f, .41f); colors.pressedColor = new Color(.08f, .35f, .48f); colors.selectedColor = colors.highlightedColor; button.colors = colors;
        Text(label, go.transform, 18, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter, Vector2.zero, size - new Vector2(16, 8));
        return button;
    }

    static void Stretch(RectTransform rect)
    {
        rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one; rect.pivot = new Vector2(.5f, .5f); rect.anchoredPosition = Vector2.zero; rect.sizeDelta = Vector2.zero;
    }
}
