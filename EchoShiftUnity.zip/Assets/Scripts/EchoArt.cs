using System.Collections.Generic;
using UnityEngine;

/// <summary>Small, code-drawn sprite kit used by the prototype. No external art packs are required.</summary>
public static class EchoArt
{
    static Sprite white;
    static Sprite ring;
    static Sprite orb;
    static PlayerFrames playerFrames;

    public sealed class PlayerFrames
    {
        public Sprite[] idle, run;
        public Sprite jump, fall;
    }

    public static Sprite White
    {
        get
        {
            if (white != null) return white;
            var tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            tex.SetPixels(new[] { Color.white, Color.white, Color.white, Color.white });
            tex.filterMode = FilterMode.Point;
            tex.Apply();
            white = Sprite.Create(tex, new Rect(0, 0, 2, 2), new Vector2(.5f, .5f), 2);
            return white;
        }
    }

    public static Sprite Ring
    {
        get
        {
            if (ring != null) return ring;
            const int n = 96;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            var pixels = new Color32[n * n];
            float c = (n - 1) * .5f;
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(c, c));
                float a = Mathf.Clamp01(1f - Mathf.Abs(d - 39f) / 5.5f);
                pixels[y * n + x] = new Color32(255, 255, 255, (byte)(a * 255));
            }
            tex.SetPixels32(pixels); tex.Apply();
            ring = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(.5f, .5f), 48);
            return ring;
        }
    }

    public static Sprite Orb
    {
        get
        {
            if (orb != null) return orb;
            const int n = 64;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            var pixels = new Color32[n * n];
            float c = (n - 1) * .5f;
            for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(c, c)) / (n * .47f);
                float a = Mathf.Pow(Mathf.Clamp01(1f - d), 2.2f);
                pixels[y * n + x] = new Color32(255, 255, 255, (byte)(a * 220));
            }
            tex.SetPixels32(pixels); tex.Apply();
            orb = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(.5f, .5f), 32);
            return orb;
        }
    }

    public static PlayerFrames Player
    {
        get
        {
            if (playerFrames != null) return playerFrames;
            playerFrames = new PlayerFrames
            {
                idle = new[] { MakePlayerFrame(0), MakePlayerFrame(1) },
                run = new[] { MakePlayerFrame(2), MakePlayerFrame(3), MakePlayerFrame(4), MakePlayerFrame(5) },
                jump = MakePlayerFrame(6), fall = MakePlayerFrame(7)
            };
            return playerFrames;
        }
    }

    public static GameObject Rect(string name, Transform parent, Vector3 position, Vector3 size, Color color, int order = 0)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.position = position;
        go.transform.localScale = size;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = White; sr.color = color; sr.sortingOrder = order;
        return go;
    }

    public static SpriteRenderer SpriteObject(string name, Transform parent, Vector3 position, Vector3 size, Sprite sprite, Color color, int order = 0)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.position = position;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite; sr.color = color; sr.sortingOrder = order;
        Vector3 bounds = sprite.bounds.size;
        go.transform.localScale = new Vector3(size.x / Mathf.Max(.0001f, bounds.x), size.y / Mathf.Max(.0001f, bounds.y), 1);
        return sr;
    }

    static Sprite MakePlayerFrame(int pose)
    {
        const int w = 32, h = 44;
        var px = new Color32[w * h];
        Color32 outline = new Color32(17, 26, 47, 255);
        Color32 shell = new Color32(224, 235, 244, 255);
        Color32 shade = new Color32(138, 165, 190, 255);
        Color32 cyan = new Color32(43, 238, 255, 255);
        Color32 cyanDark = new Color32(21, 107, 143, 255);
        Color32 coral = new Color32(255, 174, 74, 255);
        Color32 boot = new Color32(255, 114, 83, 255);

        void Fill(int x, int y, int rw, int rh, Color32 c)
        {
            for (int yy = y; yy < y + rh; yy++) for (int xx = x; xx < x + rw; xx++)
                if (xx >= 0 && xx < w && yy >= 0 && yy < h) px[yy * w + xx] = c;
        }
        void Limb(int x0, int y0, int x1, int y1, Color32 c, int thick = 2)
        {
            int steps = Mathf.Max(Mathf.Abs(x1 - x0), Mathf.Abs(y1 - y0));
            for (int i = 0; i <= steps; i++)
            {
                float t = steps == 0 ? 0 : i / (float)steps;
                Fill(Mathf.RoundToInt(Mathf.Lerp(x0, x1, t)), Mathf.RoundToInt(Mathf.Lerp(y0, y1, t)), thick, thick, c);
            }
        }

        // Antenna and head.
        Fill(15, 40, 2, 3, outline); Fill(15, 41, 2, 2, cyan);
        Fill(7, 28, 18, 13, outline); Fill(8, 29, 16, 11, shell); Fill(8, 29, 3, 9, shade);
        Fill(10, 32, 13, 5, cyanDark); Fill(11, 33, 11, 3, new Color32(19, 42, 66, 255));
        Fill(13, 34, 2, 2, cyan); Fill(19, 34, 2, 2, cyan);
        Fill(21, 38, 3, 2, coral);
        // Back scarf.
        Fill(pose % 2 == 0 ? 3 : 4, 20, 7, 3, outline); Fill(pose % 2 == 0 ? 4 : 5, 21, 6, 2, coral);
        // Arms swing with the run cycle.
        int swing = pose >= 2 && pose <= 5 ? (pose == 2 || pose == 5 ? 2 : -2) : 0;
        Limb(10, 25, 6 + swing, 18, outline, 4); Limb(11, 25, 7 + swing, 19, shell, 2);
        Limb(21, 25, 25 - swing, 18, outline, 4); Limb(22, 25, 25 - swing, 19, shell, 2);
        // Torso, chest light and waist.
        Fill(9, 15, 14, 14, outline); Fill(10, 16, 12, 12, shell); Fill(10, 16, 3, 10, shade);
        Fill(13, 21, 6, 5, cyanDark); Fill(14, 22, 4, 3, cyan); Fill(10, 14, 12, 2, coral);
        // Separate leg poses make the tiny character feel alive at game scale.
        int leg = pose >= 2 && pose <= 5 ? (pose == 2 ? -2 : pose == 4 ? 2 : 0) : 0;
        if (pose == 6) { Limb(13, 15, 9, 7, outline, 4); Limb(19, 15, 23, 7, outline, 4); Fill(6, 5, 6, 3, boot); Fill(21, 5, 6, 3, boot); }
        else if (pose == 7) { Limb(13, 15, 11, 8, outline, 4); Limb(19, 15, 22, 8, outline, 4); Fill(8, 6, 6, 3, boot); Fill(20, 6, 6, 3, boot); }
        else
        {
            Limb(13, 15, 12 + leg, 7, outline, 4); Limb(19, 15, 20 - leg, 7, outline, 4);
            Fill(9 + leg, 5, 7, 3, boot); Fill(18 - leg, 5, 7, 3, boot);
        }
        // A small glint keeps the face readable at low resolution.
        Fill(11, 38, 2, 1, Color.white);

        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point; tex.wrapMode = TextureWrapMode.Clamp;
        tex.SetPixels32(px); tex.Apply();
        var sprite = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(.5f, 0), 30);
        sprite.name = "Echo Runner Frame " + pose;
        return sprite;
    }
}
