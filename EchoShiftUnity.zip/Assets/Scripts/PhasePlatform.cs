using UnityEngine;

public class PhasePlatform : MonoBehaviour
{
    public EchoShiftGame.WorldPhase worldPhase;
    public Collider2D platformCollider;
    public SpriteRenderer[] phaseRenderers;
    public float moveAmplitude;
    public float movePeriod = 2.8f;
    public Vector2 Velocity { get; private set; }
    Vector3 origin;
    float phaseOffset;
    Rigidbody2D body;

    public void Initialize(EchoShiftGame.WorldPhase phase, Collider2D col, SpriteRenderer[] renderers, float amplitude, float period)
    {
        worldPhase = phase; platformCollider = col; phaseRenderers = renderers;
        moveAmplitude = amplitude; movePeriod = Mathf.Max(.1f, period);
        origin = transform.position; phaseOffset = Random.Range(0f, 6.28f);
        if (moveAmplitude > 0)
        {
            body = gameObject.AddComponent<Rigidbody2D>(); body.bodyType = RigidbodyType2D.Kinematic;
            body.freezeRotation = true; body.interpolation = RigidbodyInterpolation2D.Interpolate;
        }
    }

    public void SetActivePhase(EchoShiftGame.WorldPhase phase)
    {
        bool active = phase == worldPhase;
        if (platformCollider != null) platformCollider.enabled = active;
        if (phaseRenderers != null) foreach (var renderer in phaseRenderers) if (renderer != null) renderer.enabled = active;
    }

    void FixedUpdate()
    {
        if (moveAmplitude > 0 && body != null)
        {
            float x = Mathf.Sin(Time.fixedTime * (Mathf.PI * 2f / movePeriod) + phaseOffset) * moveAmplitude;
            Vector2 target = new Vector2(origin.x + x, origin.y);
            Velocity = (target - body.position) / Time.fixedDeltaTime;
            body.MovePosition(target);
        }
        else Velocity = Vector2.zero;
    }
}
