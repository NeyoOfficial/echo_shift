using System.Collections.Generic;
using UnityEngine;

public static class EchoLevelBuilder
{
    public sealed class BuiltLevel
    {
        public PlayerController2D player;
        public float exitY;
        public float roomHeight;
        public float lavaSpeed;
        public int requiredCores;
        public string title;
        public string subtitle;
    }

    sealed class LevelSpec
    {
        public string title, subtitle;
        public int pads, cores;
        public float gap, firstY, padWidth, lavaSpeed;
        public float roomHeight;
        public float[] xs;
        public int[] coreIndices;
        public int[] movingIndices;
        public float movingDistance;
    }

    static readonly LevelSpec[] levels = CreateLevels();

    static LevelSpec[] CreateLevels()
    {
        var result = new List<LevelSpec>
        {
        new LevelSpec { title="SAMOUCZEK / ISKRA", subtitle="Naucz się skakać, zmieniać fazę i zbierać rdzeń.", pads=6, gap=1.8f, firstY=2.2f, padWidth=3.25f, lavaSpeed=.24f, roomHeight=18f, cores=1,
            xs=new[]{-1.7f,1.75f,-1.6f,1.65f,-1.7f,1.65f}, coreIndices=new[]{1}, movingIndices=new int[0] },
        new LevelSpec { title="01 / ROZGRZEWKA", subtitle="Szerokie platformy i jeden rdzeń rezonansu.", pads=9, gap=1.78f, firstY=2.1f, padWidth=2.95f, lavaSpeed=.27f, roomHeight=23f, cores=1,
            xs=new[]{-1.9f,1.85f,-1.5f,2.05f,-2.1f,1.55f,-.85f,2.25f,-1.85f}, coreIndices=new[]{4}, movingIndices=new int[0] },
        new LevelSpec { title="02 / REZONANS", subtitle="Zbierz trzy rdzenie rozsiane po szybie. Wszystkie są oznaczone w HUD.", pads=14, gap=1.95f, firstY=2.25f, padWidth=2.35f, lavaSpeed=.30f, roomHeight=34.5f, cores=3,
            xs=new[]{-2.5f,1.4f,2.65f,-1.65f,-2.65f,1.9f,2.45f,-1.4f,-2.6f,1.75f,.1f,2.55f,-2.3f,.1f}, coreIndices=new[]{2,7,11}, movingIndices=new[]{4,8,12}, movingDistance=.72f },
        new LevelSpec { title="03 / PRZESUNIĘCIE", subtitle="Wąskie platformy i częstsze zmiany fazy.", pads=20, gap=1.85f, firstY=2.15f, padWidth=1.82f, lavaSpeed=.315f, roomHeight=43.5f, cores=4,
            xs=new[]{2.45f,-2.55f,-.1f,2.65f,-2.65f,.15f,2.7f,-2.55f,.05f,2.65f,-2.65f,.1f,2.6f,-2.45f,0f,2.55f,-2.5f,.05f,2.6f,-2.55f}, coreIndices=new[]{2,6,11,16}, movingIndices=new[]{1,3,5,7,9,11,13,15,17,19}, movingDistance=1.08f },
        new LevelSpec { title="04 / ZAPADNIA", subtitle="Ruchome platformy, cztery rdzenie i szybsza lawa.", pads=22, gap=1.9f, firstY=2.1f, padWidth=1.62f, lavaSpeed=.355f, roomHeight=48.5f, cores=4,
            xs=new[]{-2.55f,2.5f,-.2f,2.75f,-2.65f,.15f,2.45f,-2.65f,.2f,2.7f,-2.5f,.05f,2.6f,-2.7f,.1f,2.65f,-2.55f,0f,2.6f,-2.6f,0f,2.4f}, coreIndices=new[]{3,8,14,19}, movingIndices=new[]{2,5,8,11,14,17,20}, movingDistance=1.12f },
        new LevelSpec { title="05 / OSTATNI SYGNAŁ", subtitle="Szybka lawa, pięć rdzeni i wąskie ruchome platformy.", pads=26, gap=1.9f, firstY=2.05f, padWidth=1.42f, lavaSpeed=.40f, roomHeight=56.5f, cores=5,
            xs=new[]{2.65f,-2.6f,0f,2.7f,-2.65f,0f,2.55f,-2.7f,.05f,2.7f,-2.6f,.05f,2.7f,-2.65f,0f,2.65f,-2.7f,.05f,2.65f,-2.55f,0f,2.7f,-2.65f,.05f,2.6f,-2.65f}, coreIndices=new[]{2,7,12,17,22}, movingIndices=new[]{1,3,5,7,9,11,13,15,17,19,21,23,25}, movingDistance=1.28f }
        };

        string[] names =
        {
            "ŻAROWY KORYTARZ", "MOST Z ECHA", "WAHADŁA", "PRÓBA RDZENIA", "KOMORA PAROWA", "ŻELAZNA DRABINA",
            "FALE CIŚNIENIA", "PĘKNIĘTY SZYB", "RUCHOME ŻEBRA", "ŻAR W CIEMNOŚCI", "KRĄG PRZESUNIĘCIA", "STALOWY WIR",
            "KOMORA WYCIEKU", "OSTATNI ZAWÓR", "PIEC REZONANSU", "WĄSKIE PRZEJŚCIE", "PĘTLA MAGMY", "WYSOKIE CIŚNIENIE",
            "JĄDRO BURZY", "ROZPADLINA", "NIEDOSTĘPNY MOST", "CZERWONY ALARM", "ŻAROWA KATEDRA", "OSTATNIA UCIECZKA"
        };

        // The first six stages retain their hand-tuned layouts. The final 24 grow
        // steadily longer, narrower, hotter, and more reliant on moving platforms.
        for (int rank = 1; rank <= names.Length; rank++)
        {
            float t = (rank - 1) / (float)(names.Length - 1);
            int pads = 26 + rank / 2;
            float gap = Mathf.Lerp(1.91f, 2.00f, t);
            float firstY = Mathf.Lerp(2.04f, 1.98f, t);
            float padWidth = Mathf.Lerp(1.38f, 1.12f, t);
            float lavaSpeed = Mathf.Lerp(.405f, .49f, t);
            float movingDistance = Mathf.Lerp(1.30f, 1.42f, t);
            int coreCount = Mathf.Min(8, 5 + rank / 8);
            int movingCount = Mathf.Min((pads + 1) / 2, 13 + rank / 4);
            int[] coreIndices = new int[coreCount];
            for (int c = 0; c < coreCount; c++)
                coreIndices[c] = Mathf.Clamp(Mathf.RoundToInt((c + 1) * (pads - 1f) / (coreCount + 1f)), 1, pads - 2);
            int[] movingIndices = new int[movingCount];
            for (int m = 0; m < movingCount; m++)
                movingIndices[m] = Mathf.Clamp(1 + Mathf.RoundToInt((m + 1) * (pads - 2f) / (movingCount + 1f)), 1, pads - 1);
            float[] xs = new float[pads];
            var layoutRandom = new System.Random(8600 + rank * 97);
            for (int i = 0; i < xs.Length; i++) xs[i] = (float)layoutRandom.NextDouble() * 4f - 2f;
            float exitY = firstY + gap * pads;

            result.Add(new LevelSpec
            {
                title = (result.Count).ToString("00") + " / " + names[rank - 1],
                subtitle = "Etap " + (result.Count).ToString("00") + ": " + pads + " platform, " + coreCount + " rdzeni. Uważaj na lawę i zmieniaj fazy.",
                pads = pads, gap = gap, firstY = firstY, padWidth = padWidth, lavaSpeed = lavaSpeed,
                roomHeight = exitY + 6.5f, cores = coreCount, xs = xs, coreIndices = coreIndices,
                movingIndices = movingIndices, movingDistance = movingDistance
            });
        }
        return result.ToArray();
    }

    public static int Count { get { return levels.Length; } }

    public static string TitleFor(int index) { return levels[Mathf.Clamp(index, 0, levels.Length - 1)].title; }

    public static string DifficultyFor(int index)
    {
        int stage = Mathf.Clamp(index, 0, levels.Length - 1);
        if (stage == 0) return "SAMOUCZEK";
        if (stage == 1) return "ŁATWY";
        if (stage == 2) return "ŚREDNI";
        if (stage <= 11) return "TRUDNY";
        return "BARDZO TRUDNY";
    }

    public static BuiltLevel Build(EchoShiftGame game, Transform root, int index)
    {
        LevelSpec spec = levels[Mathf.Clamp(index, 0, levels.Length - 1)];
        float exitY = spec.firstY + spec.gap * spec.pads;
        BuildRoom(root, spec.roomHeight, index);
        BuildWalls(root, spec.roomHeight);
        var phasePlatforms = new List<PhasePlatform>();
        AddPlatform(game, root, "Safe Start", 0, 0, 10.5f, EchoShiftGame.WorldPhase.Material, 0, .46f, index, phasePlatforms);
        for (int i = 0; i < spec.pads; i++)
        {
            float x = GeneratedPlatformX(spec, i);
            float y = spec.firstY + spec.gap * i;
            var phase = i % 2 == 0 ? EchoShiftGame.WorldPhase.Material : EchoShiftGame.WorldPhase.Echo;
            float width = spec.padWidth - (index == 2 && i % 3 == 1 ? .22f : 0f);
            float moving = Contains(spec.movingIndices, i) ? spec.movingDistance : 0f;
            PhasePlatform platform = AddPlatform(game, root, "Phase Platform " + (i + 1).ToString("00"), x, y, width, phase, moving, .42f, index, phasePlatforms);
            if (Contains(spec.coreIndices, i))
            {
                var core = new GameObject("Resonance Core"); core.transform.SetParent(platform.transform, false); core.transform.position = new Vector3(x, y + 1.15f, -.35f);
                core.AddComponent<ResonanceCore>().Initialize(game, phase);
            }
        }
        AddPlatform(game, root, "Exit Landing", 0, exitY, 3.5f, EchoShiftGame.WorldPhase.Material, 0, .5f, index, phasePlatforms);
        BuildGoal(game, root, exitY + .82f);

        var playerGo = new GameObject("Echo Runner"); playerGo.transform.SetParent(root, false); playerGo.transform.position = new Vector3(0, 1.1f, -.3f);
        var playerSprite = playerGo.AddComponent<SpriteRenderer>(); playerSprite.sprite = EchoArt.Player.idle[0]; playerSprite.sortingOrder = 8;
        var rb = playerGo.AddComponent<Rigidbody2D>(); rb.gravityScale = 2.35f; rb.freezeRotation = true; rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous; rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation; rb.mass = 1;
        var box = playerGo.AddComponent<BoxCollider2D>(); box.size = new Vector2(.76f, 1.18f); box.offset = new Vector2(0, .58f);
        playerGo.layer = 8;
        var controller = playerGo.AddComponent<PlayerController2D>(); controller.groundMask = 1 << 7;

        var lavaGo = new GameObject("Slow Rising Lava"); lavaGo.layer = 0;
        lavaGo.AddComponent<RisingLava>().Initialize(game, root, 12f, -3.05f, spec.lavaSpeed, spec.roomHeight);
        return new BuiltLevel { player=controller, exitY=exitY + .7f, roomHeight=spec.roomHeight, lavaSpeed=spec.lavaSpeed, requiredCores=spec.cores, title=spec.title, subtitle=spec.subtitle };
    }

    static bool Contains(int[] values, int n) { for (int i = 0; i < values.Length; i++) if (values[i] == n) return true; return false; }

    static float GeneratedPlatformX(LevelSpec spec, int index)
    {
        // Same-phase platforms alternate sides, so an active platform is never directly
        // above the previous active platform. Reserve room for moving platforms as well.
        float lane = Mathf.Max(1.7f, (spec.padWidth + spec.movingDistance * 2f + .55f) * .5f + .08f);
        int samePhasePair = index / 2;
        float pairSide = samePhasePair % 2 == 0 ? -1f : 1f;
        float side = index % 2 == 0 ? pairSide : -pairSide;
        float phaseOffset = index % 2 == 0 ? -.12f : .12f;
        float variation = Mathf.Clamp(spec.xs[index % spec.xs.Length] * .12f, -.28f, .28f)
                        + Mathf.Sin(index * 1.7f + spec.pads) * .045f;
        return side * lane + phaseOffset + variation;
    }

    static PhasePlatform AddPlatform(EchoShiftGame game, Transform root, string name, float x, float y, float width, EchoShiftGame.WorldPhase phase, float movement, float thickness, int level, List<PhasePlatform> register)
    {
        var go = new GameObject(name); go.transform.SetParent(root, false); go.transform.position = new Vector3(x, y, 0);
        var col = go.AddComponent<BoxCollider2D>(); col.size = new Vector2(width, thickness); col.offset = Vector2.zero;
        col.usedByEffector = true;
        var oneWay = go.AddComponent<PlatformEffector2D>(); oneWay.useOneWay = true; oneWay.surfaceArc = 180f;
        go.layer = 7;
        Color baseColor = phase == EchoShiftGame.WorldPhase.Material ? new Color(.24f, .92f, 1f) : new Color(.91f, .43f, 1f);
        if (level == 2 && phase == EchoShiftGame.WorldPhase.Material) baseColor = new Color(1f, .67f, .32f);
        var plate = EchoArt.SpriteObject("Platform Surface", go.transform, go.transform.position + new Vector3(0, 0, .02f), new Vector3(width, thickness, 1), EchoArt.White, new Color(.035f, .085f, .16f), 2);
        var top = EchoArt.SpriteObject("Neon Contact Edge", go.transform, go.transform.position + new Vector3(0, thickness * .5f - .035f, -.04f), new Vector3(width - .08f, .07f, 1), EchoArt.White, baseColor, 4);
        var glow = EchoArt.SpriteObject("Phase Halo", go.transform, go.transform.position + new Vector3(0, .08f, .08f), new Vector3(width + .38f, .85f, 1), EchoArt.Orb, new Color(baseColor.r, baseColor.g, baseColor.b, .16f), 0);
        var capL = EchoArt.SpriteObject("End Cap", go.transform, go.transform.position + new Vector3(-width * .5f + .04f, 0, -.06f), new Vector3(.1f, thickness + .12f, 1), EchoArt.White, baseColor, 3);
        var capR = EchoArt.SpriteObject("End Cap", go.transform, go.transform.position + new Vector3(width * .5f - .04f, 0, -.06f), new Vector3(.1f, thickness + .12f, 1), EchoArt.White, baseColor, 3);
        var deco = new List<SpriteRenderer> { plate, top, glow, capL, capR };
        if (movement > 0)
        {
            var beacon = EchoArt.SpriteObject("Motion Beacon", go.transform, go.transform.position + new Vector3(0, thickness + .21f, 0), new Vector3(.16f, .16f, 1), EchoArt.Orb, Color.white, 5);
            deco.Add(beacon);
        }
        float movePeriod = level >= 6
            ? Mathf.Lerp(1.92f, 1.68f, Mathf.InverseLerp(6, levels.Length - 1, level))
            : level >= 5 ? 1.95f : level >= 4 ? 2.2f : level >= 3 ? 2.55f : level == 2 ? 3.5f : 2.8f;
        var platform = go.AddComponent<PhasePlatform>(); platform.Initialize(phase, col, deco.ToArray(), movement, movePeriod);
        platform.SetActivePhase(game.CurrentPhase); game.RegisterPlatform(platform); register.Add(platform);
        // The phase highlight gently breathes while the platform is active.
        var shimmer = go.AddComponent<PlatformShimmer>(); shimmer.Initialize(glow, baseColor);
        return platform;
    }

    static void BuildGoal(EchoShiftGame game, Transform root, float y)
    {
        var gate = new GameObject("Exit Beacon"); gate.transform.SetParent(root, false); gate.transform.position = new Vector3(0, y, -.1f);
        var trigger = gate.AddComponent<BoxCollider2D>(); trigger.isTrigger = true; trigger.size = new Vector2(1.35f, 2.05f);
        EchoArt.SpriteObject("Gate Arch", gate.transform, gate.transform.position, new Vector3(1.25f, 2.05f, 1), EchoArt.White, new Color(.08f, .13f, .24f), 3);
        EchoArt.SpriteObject("Gate Interior", gate.transform, gate.transform.position + new Vector3(0, 0, -.03f), new Vector3(.8f, 1.55f, 1), EchoArt.Orb, new Color(.23f, .88f, 1f, .65f), 4);
        var beacon = EchoArt.SpriteObject("Gate Status Light", gate.transform, gate.transform.position + new Vector3(0, .95f, -.07f), new Vector3(.23f, .23f, 1), EchoArt.Orb, Color.green, 6);
        EchoArt.SpriteObject("Gate Frame Glow", gate.transform, gate.transform.position, new Vector3(1.48f, 2.15f, 1), EchoArt.Ring, new Color(.3f, .95f, 1f, .42f), 2);
        gate.AddComponent<EchoGoal>().Initialize(game, beacon);
    }

    static void BuildWalls(Transform root, float height)
    {
        foreach (float x in new[] { -6.15f, 6.15f })
        {
            var wall = EchoArt.Rect("Containment Wall", root, new Vector3(x, height * .5f - 1, 0), new Vector3(.55f, height + 5f, 1), new Color(.04f, .075f, .13f), 2);
            var col = wall.AddComponent<BoxCollider2D>(); col.size = Vector2.one; wall.layer = 7;
            EchoArt.Rect("Wall Spine", root, new Vector3(x * .94f, height * .5f - 1, .12f), new Vector3(.07f, height + 4f, 1), new Color(.17f, .41f, .56f, .42f), 3);
            for (float y = 1.5f; y < height; y += 4f)
                EchoArt.SpriteObject("Wall Signal", root, new Vector3(x * .94f, y, -.05f), new Vector3(.24f, .24f, 1), EchoArt.Orb, new Color(.24f, .9f, 1f, .55f), 4);
        }
    }

    static void BuildRoom(Transform root, float height, int level)
    {
        Color[] atmospheres =
        {
            new Color(.018f, .033f, .09f), new Color(.018f, .045f, .085f), new Color(.06f, .025f, .095f),
            new Color(.075f, .025f, .065f), new Color(.095f, .032f, .045f), new Color(.08f, .015f, .035f)
        };
        Color[] bands =
        {
            new Color(.08f, .14f, .27f, .42f), new Color(.06f, .2f, .28f, .42f), new Color(.19f, .07f, .26f, .44f),
            new Color(.27f, .075f, .14f, .45f), new Color(.34f, .1f, .09f, .47f), new Color(.38f, .035f, .08f, .5f)
        };
        int palette = level % atmospheres.Length;
        EchoArt.Rect("Deep Shaft", root, new Vector3(0, height * .5f - 1, 4), new Vector3(13.6f, height + 6f, 1), atmospheres[palette], -8);
        EchoArt.Rect("Far Light Column", root, new Vector3(-3.8f, height * .5f - 1, 3.6f), new Vector3(1.4f, height + 2f, 1), bands[palette], -7);
        EchoArt.Rect("Far Light Column", root, new Vector3(3.4f, height * .5f - 1, 3.7f), new Vector3(2.1f, height + 2f, 1), new Color(bands[palette].r, bands[palette].g, bands[palette].b, .25f), -7);
        var rng = new System.Random(210 + level);
        int starCount = Mathf.RoundToInt(height * 3.2f);
        for (int i = 0; i < starCount; i++)
        {
            float x = (float)rng.NextDouble() * 11f - 5.5f;
            float y = (float)rng.NextDouble() * (height - 1f);
            float s = .025f + (float)rng.NextDouble() * .055f;
            Color c = i % 5 == 0 ? new Color(.33f, .81f, 1f, .72f) : new Color(.53f, .66f, .87f, .38f);
            EchoArt.SpriteObject("Dust mote", root, new Vector3(x, y, 2.9f), new Vector3(s, s, 1), EchoArt.Orb, c, -5);
        }
        // Repeated cross braces make the climb feel like a deep, mechanical reactor shaft.
        for (float y = 3.5f; y < height; y += 5.2f)
        {
            EchoArt.Rect("Cross brace", root, new Vector3(0, y, 2.4f), new Vector3(10.7f, .035f, 1), new Color(.17f, .3f, .48f, .34f), -4);
            EchoArt.Rect("Brace Node", root, new Vector3(-5.25f, y, 2.2f), new Vector3(.18f, .18f, 1), new Color(.24f, .85f, 1f, .65f), -3);
            EchoArt.Rect("Brace Node", root, new Vector3(5.25f, y, 2.2f), new Vector3(.18f, .18f, 1), new Color(.24f, .85f, 1f, .65f), -3);
        }
    }
}

public class PlatformShimmer : MonoBehaviour
{
    SpriteRenderer rendererRef;
    Color baseColor;
    public void Initialize(SpriteRenderer sr, Color color) { rendererRef = sr; baseColor = color; }
    void Update()
    {
        if (rendererRef == null || !rendererRef.enabled) return;
        float p = .11f + (Mathf.Sin(Time.time * 3.4f + transform.position.y) + 1f) * .035f;
        rendererRef.color = new Color(baseColor.r, baseColor.g, baseColor.b, p);
    }
}
