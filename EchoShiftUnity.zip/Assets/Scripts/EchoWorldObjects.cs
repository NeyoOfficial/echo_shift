using UnityEngine;

public class RisingLava : MonoBehaviour
{
    const int WaveSegments = 72;
    static Sprite lavaGradient;
    EchoShiftGame game;
    float speed, surfaceY, depth, width, startY;
    SpriteRenderer bodyRenderer;
    SpriteRenderer surfaceGlow;
    Transform bubbleRoot;
    float[] bubblePhase;
    float[] bubbleHeight;
    SpriteRenderer[] bubbleRenderers;
    Vector3[] bubbleSizes;
    Mesh surfaceMesh;
    Material surfaceMaterial;
    Vector3[] surfaceVertices;
    Color[] surfaceColors;
    LavaPour[] pours;
    bool killed;

    public float SurfaceY { get { return surfaceY; } }

    public void Initialize(EchoShiftGame owner, Transform parent, float roomWidth, float startLevel, float riseSpeed, float roomHeight)
    {
        game = owner; width = roomWidth; startY = startLevel; surfaceY = startLevel; speed = riseSpeed; depth = roomHeight + 30f;
        transform.SetParent(parent, false); transform.position = Vector3.zero;
        var body = EchoArt.Rect("Lava Body", transform, Vector3.zero, new Vector3(width, depth, 1), new Color(.9f, .13f, .025f), 1);
        body.transform.position = new Vector3(0, surfaceY - depth * .5f, .1f);
        bodyRenderer = body.GetComponent<SpriteRenderer>();
        bodyRenderer.color = Color.white;
        bodyRenderer.sprite = CreateLavaGradient();
        body.transform.localScale = new Vector3(width / bodyRenderer.sprite.bounds.size.x, depth / bodyRenderer.sprite.bounds.size.y, 1);
        var hitbox = body.AddComponent<BoxCollider2D>(); hitbox.isTrigger = true; hitbox.size = bodyRenderer.sprite.bounds.size;
        var glow = EchoArt.SpriteObject("Molten Edge Glow", transform, new Vector3(0, surfaceY, -.05f), new Vector3(width, .9f, 1), EchoArt.Orb, new Color(1f, .26f, .035f, .34f), 2);
        surfaceGlow = glow;

        CreateSurfaceMesh();
        CreatePipesAndPours();

        bubbleRoot = new GameObject("Lava Bubbles").transform; bubbleRoot.SetParent(transform, false);
        bubblePhase = new float[30]; bubbleHeight = new float[30];
        bubbleRenderers = new SpriteRenderer[bubblePhase.Length]; bubbleSizes = new Vector3[bubblePhase.Length];
        for (int i = 0; i < bubblePhase.Length; i++)
        {
            bubblePhase[i] = Random.Range(0f, 6.28f); bubbleHeight[i] = Random.Range(0f, 8.5f);
            bubbleSizes[i] = Vector3.one * Random.Range(.055f, .16f);
            bubbleRenderers[i] = EchoArt.SpriteObject("Rising ember bubble", bubbleRoot,
                new Vector3(Random.Range(-width * .46f, width * .46f), surfaceY - Random.Range(.4f, 5f), -.12f),
                bubbleSizes[i], EchoArt.Orb, new Color(1f, Random.Range(.3f, .82f), .08f, .82f), 4);
        }
        var rb = gameObject.AddComponent<Rigidbody2D>(); rb.bodyType = RigidbodyType2D.Kinematic; rb.simulated = true;
        rb.position = Vector2.zero;
    }

    void Update()
    {
        if (game == null || game.State != EchoShiftGame.GameState.Playing) return;
        surfaceY += speed * Time.deltaTime;
        if (bodyRenderer != null) bodyRenderer.transform.position = new Vector3(0, surfaceY - depth * .5f, .1f);
        if (surfaceGlow != null)
        {
            surfaceGlow.transform.position = new Vector3(0, surfaceY, -.05f);
            float glowPulse = 1f + Mathf.Sin(Time.time * 2.4f) * .08f;
            Vector2 glowSpriteSize = surfaceGlow.sprite.bounds.size;
            surfaceGlow.transform.localScale = new Vector3(width * 1.25f / glowSpriteSize.x, .9f * glowPulse / glowSpriteSize.y, 1);
        }
        AnimateSurface();
        for (int i = 0; i < pours.Length; i++) pours[i].Animate(surfaceY, Time.time);
        for (int i = 0; i < bubbleRoot.childCount; i++)
        {
            Transform b = bubbleRoot.GetChild(i);
            float y = Mathf.Repeat(Time.time * (.52f + i % 4 * .14f) + bubbleHeight[i], 8.2f);
            float x = Mathf.Sin(Time.time * (.65f + i % 3 * .12f) + bubblePhase[i]) * width * .44f;
            b.position = new Vector3(x, surfaceY - y, -.12f);
            float pulse = 1f + Mathf.Sin(Time.time * 4f + bubblePhase[i]) * .22f;
            b.localScale = bubbleSizes[i] * pulse;
            Color bubbleColor = bubbleRenderers[i].color;
            bubbleColor.a = .42f + .48f * Mathf.Clamp01(y / 1.5f);
            bubbleRenderers[i].color = bubbleColor;
        }
        var player = game.Player;
        if (!killed && player != null && player.transform.position.y - .45f <= surfaceY)
        {
            killed = true;
            game.PlayerCaughtByLava();
        }
    }

    void CreatePipesAndPours()
    {
        // Sewer-like feed lines climb the shaft in visible right-angle bends before spilling into the pool.
        Vector2[] leftRoute =
        {
            new Vector2(-5.35f, -2.72f), new Vector2(-5.35f, -1.78f), new Vector2(-4.55f, -1.78f),
            new Vector2(-4.55f, -.92f), new Vector2(-3.82f, -.92f), new Vector2(-3.82f, -.30f)
        };
        Vector2[] rightRoute =
        {
            new Vector2(5.35f, -2.85f), new Vector2(5.35f, -2.05f), new Vector2(4.58f, -2.05f),
            new Vector2(4.58f, -1.18f), new Vector2(3.82f, -1.18f), new Vector2(3.82f, -.05f)
        };
        CreatePipeRoute("Left sewer", leftRoute, 0f);
        CreatePipeRoute("Right sewer", rightRoute, 2.1f);
        pours = new[]
        {
            new LavaPour(transform, leftRoute[leftRoute.Length - 1], 0, surfaceMaterial),
            new LavaPour(transform, rightRoute[rightRoute.Length - 1], 1, surfaceMaterial)
        };
    }

    void CreatePipeRoute(string label, Vector2[] points, float offset)
    {
        for (int i = 0; i < points.Length - 1; i++)
        {
            Vector2 a = points[i], b = points[i + 1];
            CreatePipeSegment(label + " shell", a, b, .46f, new Color(.15f, .24f, .34f), -2);
            CreatePipeSegment(label + " dark channel", a, b, .29f, new Color(.035f, .052f, .075f), -1);
            CreatePipeSegment(label + " molten groove", a, b, .105f, new Color(1f, .23f, .035f, .78f), 0);
        }
        for (int i = 0; i < points.Length - 1; i++)
        {
            Vector2 corner = points[i];
            EchoArt.SpriteObject(label + " elbow", transform, new Vector3(corner.x, corner.y, .04f),
                new Vector3(.52f, .52f, 1), EchoArt.White, new Color(.19f, .29f, .39f), -2);
            EchoArt.SpriteObject(label + " elbow core", transform, new Vector3(corner.x, corner.y, .02f),
                new Vector3(.25f, .25f, 1), EchoArt.Orb, new Color(1f, .22f, .035f, .78f), 0);
        }
        Vector2 outlet = points[points.Length - 1];
        EchoArt.SpriteObject(label + " outlet collar", transform, new Vector3(outlet.x, outlet.y, -.02f),
            new Vector3(.68f, .46f, 1), EchoArt.White, new Color(.31f, .41f, .49f), -1);
        EchoArt.SpriteObject(label + " hot outlet", transform, new Vector3(outlet.x, outlet.y - .08f, -.05f),
            new Vector3(.35f, .18f, 1), EchoArt.Orb, new Color(1f, .32f, .055f, .95f), 1);

        for (int i = 0; i < 3; i++)
        {
            var pulse = EchoArt.SpriteObject(label + " magma pulse", transform,
                new Vector3(points[0].x, points[0].y, -.08f), Vector3.one * (i == 0 ? .18f : .12f),
                EchoArt.Orb, new Color(1f, .62f, .12f, .95f), 0);
            pulse.gameObject.AddComponent<LavaPipeFlow>().Initialize(game, points, 1.65f + i * .18f, offset + i * 2.5f);
        }
    }

    void CreatePipeSegment(string name, Vector2 a, Vector2 b, float thickness, Color color, int order)
    {
        Vector2 delta = b - a;
        float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;
        var sr = EchoArt.SpriteObject(name, transform,
            new Vector3((a.x + b.x) * .5f, (a.y + b.y) * .5f, .06f),
            new Vector3(delta.magnitude + thickness * .12f, thickness, 1), EchoArt.White, color, order);
        sr.transform.rotation = Quaternion.Euler(0, 0, angle);
    }

    void CreateSurfaceMesh()
    {
        var surface = new GameObject("Animated molten surface");
        surface.transform.SetParent(transform, false);
        surface.transform.localPosition = Vector3.zero;
        var filter = surface.AddComponent<MeshFilter>();
        var renderer = surface.AddComponent<MeshRenderer>();
        Shader shader = Shader.Find("Sprites/Default");
        if (shader == null) shader = Shader.Find("Unlit/Color");
        surfaceMaterial = new Material(shader);
        renderer.sharedMaterial = surfaceMaterial;
        renderer.sortingOrder = 3;

        surfaceMesh = new Mesh(); surfaceMesh.name = "Waving lava surface"; surfaceMesh.MarkDynamic();
        int vertexCount = (WaveSegments + 1) * 2;
        surfaceVertices = new Vector3[vertexCount]; surfaceColors = new Color[vertexCount];
        int[] triangles = new int[WaveSegments * 6];
        for (int i = 0; i <= WaveSegments; i++)
        {
            int top = i * 2, bottom = top + 1;
            float x = Mathf.Lerp(-width * .5f, width * .5f, i / (float)WaveSegments);
            surfaceVertices[top] = new Vector3(x, surfaceY, -.22f);
            surfaceVertices[bottom] = new Vector3(x, surfaceY - .42f, -.22f);
            surfaceColors[top] = new Color(1f, .68f, .17f, 1f);
            surfaceColors[bottom] = new Color(1f, .19f, .018f, 1f);
            if (i < WaveSegments)
            {
                int t = i * 6;
                triangles[t] = top; triangles[t + 1] = bottom; triangles[t + 2] = top + 2;
                triangles[t + 3] = top + 2; triangles[t + 4] = bottom; triangles[t + 5] = bottom + 2;
            }
        }
        surfaceMesh.vertices = surfaceVertices; surfaceMesh.colors = surfaceColors; surfaceMesh.triangles = triangles;
        filter.sharedMesh = surfaceMesh;
    }

    void AnimateSurface()
    {
        if (surfaceMesh == null) return;
        for (int i = 0; i <= WaveSegments; i++)
        {
            float x = Mathf.Lerp(-width * .5f, width * .5f, i / (float)WaveSegments);
            float wave = Mathf.Sin(x * 1.65f + Time.time * 1.7f) * .075f
                       + Mathf.Sin(x * 3.8f - Time.time * 2.5f) * .027f
                       + Mathf.Sin(x * .72f + Time.time * 1.05f) * .035f;
            int top = i * 2, bottom = top + 1;
            surfaceVertices[top].x = x; surfaceVertices[top].y = surfaceY + wave; surfaceVertices[top].z = -.22f;
            surfaceVertices[bottom].x = x; surfaceVertices[bottom].y = surfaceY - .42f; surfaceVertices[bottom].z = -.22f;
            float shimmer = .5f + .5f * Mathf.Sin(x * 2.2f + Time.time * 3.2f);
            surfaceColors[top] = Color.Lerp(new Color(1f, .42f, .075f, 1f), new Color(1f, .79f, .26f, 1f), shimmer);
        }
        surfaceMesh.vertices = surfaceVertices;
        surfaceMesh.colors = surfaceColors;
        surfaceMesh.RecalculateBounds();
    }

    static Sprite CreateLavaGradient()
    {
        if (lavaGradient != null) return lavaGradient;
        const int w = 4, h = 48;
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear; tex.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < h; y++)
        {
            float t = y / (float)(h - 1);
            Color c = Color.Lerp(new Color(.30f, .035f, .025f), new Color(1f, .31f, .045f), t);
            for (int x = 0; x < w; x++) tex.SetPixel(x, y, c);
        }
        tex.Apply();
        lavaGradient = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(.5f, .5f), h);
        return lavaGradient;
    }

    sealed class LavaPour
    {
        const int RibbonSegments = 12;
        readonly Vector2 outlet;
        readonly SpriteRenderer glow, outletRing, impactGlow, splashRing;
        readonly SpriteRenderer[] drops = new SpriteRenderer[5];
        readonly float[] dropPhase = new float[5];
        readonly float[] dropBaseScale = new float[5];
        readonly SpriteRenderer[] splashes = new SpriteRenderer[4];
        readonly float[] splashPhase = new float[4];
        readonly float[] splashBaseScale = new float[4];
        readonly int index;
        readonly Mesh ribbonMesh;
        readonly MeshRenderer ribbonRenderer;
        readonly Vector3[] ribbonVertices;
        readonly Color[] ribbonColors;

        public LavaPour(Transform parent, Vector2 at, int number, Material sharedMaterial)
        {
            outlet = at; index = number;
            glow = EchoArt.SpriteObject("Lava fall glow", parent, new Vector3(at.x, at.y, -.14f), new Vector3(.62f, .1f, 1), EchoArt.White, new Color(1f, .16f, .018f, .42f), 2);
            outletRing = EchoArt.SpriteObject("Outlet heat ring", parent, new Vector3(at.x, at.y, -.19f), new Vector3(.72f, .72f, 1), EchoArt.Ring, new Color(1f, .34f, .075f, .8f), 2);
            impactGlow = EchoArt.SpriteObject("Lava splash glow", parent, new Vector3(at.x, at.y, -.24f), new Vector3(.9f, .32f, 1), EchoArt.Orb, new Color(1f, .26f, .025f, .8f), 4);
            splashRing = EchoArt.SpriteObject("Lava splash ring", parent, new Vector3(at.x, at.y, -.26f), new Vector3(.8f, .24f, 1), EchoArt.Ring, new Color(1f, .59f, .12f, .9f), 5);

            var ribbonObject = new GameObject("Wavering molten pour");
            ribbonObject.transform.SetParent(parent, false);
            var ribbonFilter = ribbonObject.AddComponent<MeshFilter>();
            ribbonRenderer = ribbonObject.AddComponent<MeshRenderer>();
            ribbonRenderer.sharedMaterial = sharedMaterial;
            ribbonRenderer.sortingOrder = 4;
            ribbonMesh = new Mesh(); ribbonMesh.name = "Molten pour ribbon"; ribbonMesh.MarkDynamic();
            ribbonVertices = new Vector3[(RibbonSegments + 1) * 4];
            ribbonColors = new Color[ribbonVertices.Length];
            int[] ribbonTriangles = new int[RibbonSegments * 18];
            for (int row = 0; row <= RibbonSegments; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    int tri = row * 18 + column * 6;
                    if (row >= RibbonSegments) break;
                    int top = row * 4 + column, bottom = top + 4;
                    ribbonTriangles[tri] = top; ribbonTriangles[tri + 1] = bottom; ribbonTriangles[tri + 2] = top + 1;
                    ribbonTriangles[tri + 3] = top + 1; ribbonTriangles[tri + 4] = bottom; ribbonTriangles[tri + 5] = bottom + 1;
                }
            }
            ribbonMesh.vertices = ribbonVertices; ribbonMesh.colors = ribbonColors; ribbonMesh.triangles = ribbonTriangles;
            ribbonFilter.sharedMesh = ribbonMesh;

            for (int i = 0; i < drops.Length; i++)
            {
                dropPhase[i] = i * .73f + number * .39f;
                drops[i] = EchoArt.SpriteObject("Falling lava droplet", parent, new Vector3(at.x, at.y, -.2f),
                    Vector3.one * (.065f + (i % 2) * .035f), EchoArt.Orb, new Color(1f, .59f, .12f, .95f), 4);
                dropBaseScale[i] = drops[i].transform.localScale.x;
            }
            for (int i = 0; i < splashes.Length; i++)
            {
                splashPhase[i] = i * .24f + number * .13f;
                splashes[i] = EchoArt.SpriteObject("Lava impact spark", parent, new Vector3(at.x, at.y, -.21f),
                    Vector3.one * .07f, EchoArt.Orb, new Color(1f, .7f, .16f, 0f), 4);
                splashBaseScale[i] = splashes[i].transform.localScale.x;
            }
        }

        public void Animate(float surface, float time)
        {
            float height = outlet.y - surface;
            bool flowing = height > .08f;
            glow.enabled = flowing;
            ribbonRenderer.enabled = flowing;
            for (int i = 0; i < drops.Length; i++) drops[i].enabled = flowing;
            for (int i = 0; i < splashes.Length; i++) splashes[i].enabled = flowing;
            if (!flowing)
            {
                outletRing.enabled = impactGlow.enabled = splashRing.enabled = false;
                return;
            }
            outletRing.enabled = true;
            float pulse = 1f + Mathf.Sin(time * 7f + index) * .12f;
            outletRing.transform.localScale = new Vector3(.36f * pulse, .36f * pulse, 1);
            outletRing.color = new Color(1f, .34f, .075f, .58f + .24f * pulse);
            float sway = Mathf.Sin(time * 5.4f + index * 1.7f) * .055f;
            glow.transform.position = new Vector3(outlet.x + sway, (outlet.y + surface) * .5f, -.14f);
            glow.transform.localScale = new Vector3(.56f + Mathf.Sin(time * 9f + index) * .035f, height, 1);

            // A 12-slice ribbon bends and swells on its way down, with a bright molten core.
            for (int row = 0; row <= RibbonSegments; row++)
            {
                float t = row / (float)RibbonSegments;
                float y = Mathf.Lerp(outlet.y - .04f, surface + .055f, t);
                float bend = Mathf.Sin(time * 5.1f - t * 5f + index * 1.8f) * (.018f + t * .085f);
                float centerX = outlet.x + sway + bend;
                float widthPulse = 1f + Mathf.Sin(time * 8.5f - t * 13f + index) * .17f;
                float halfWidth = (.105f + t * .065f) * widthPulse;
                float coreHalfWidth = halfWidth * (.28f + .04f * Mathf.Sin(time * 6f + t * 11f));
                int first = row * 4;
                ribbonVertices[first] = new Vector3(centerX - halfWidth, y, -.23f);
                ribbonVertices[first + 1] = new Vector3(centerX - coreHalfWidth, y, -.24f);
                ribbonVertices[first + 2] = new Vector3(centerX + coreHalfWidth, y, -.24f);
                ribbonVertices[first + 3] = new Vector3(centerX + halfWidth, y, -.23f);
                float heat = .5f + .5f * Mathf.Sin(time * 9f - t * 15f + index);
                ribbonColors[first] = new Color(1f, .19f + heat * .11f, .025f, .7f);
                ribbonColors[first + 1] = new Color(1f, .62f + heat * .28f, .16f, .96f);
                ribbonColors[first + 2] = new Color(1f, .62f + heat * .28f, .16f, .96f);
                ribbonColors[first + 3] = new Color(1f, .19f + heat * .11f, .025f, .7f);
            }
            ribbonMesh.vertices = ribbonVertices;
            ribbonMesh.colors = ribbonColors;
            ribbonMesh.RecalculateBounds();

            float impactPulse = .5f + .5f * Mathf.Sin(time * 8f + index);
            impactGlow.enabled = splashRing.enabled = true;
            impactGlow.transform.position = new Vector3(outlet.x + sway, surface + .02f, -.25f);
            impactGlow.transform.localScale = new Vector3(.39f + impactPulse * .12f, .12f + impactPulse * .05f, 1);
            Color impactColor = impactGlow.color; impactColor.a = .58f + impactPulse * .3f; impactGlow.color = impactColor;
            float ringAge = Mathf.Repeat(time * 1.1f + index * .47f, 1f);
            splashRing.transform.position = new Vector3(outlet.x + sway, surface + .06f, -.27f);
            splashRing.transform.localScale = new Vector3(.22f + ringAge * .35f, .07f + ringAge * .1f, 1);
            Color ringColor = splashRing.color; ringColor.a = .95f * (1f - ringAge); splashRing.color = ringColor;

            for (int i = 0; i < drops.Length; i++)
            {
                float travel = Mathf.Repeat(time * (1.7f + i * .16f) + dropPhase[i], height + .48f);
                if (travel < height)
                {
                    float t = travel / height;
                    float x = outlet.x + sway + Mathf.Sin(time * 6f - t * 4f + dropPhase[i]) * (.035f + t * .07f);
                    drops[i].transform.position = new Vector3(x, outlet.y - travel, -.25f);
                    drops[i].transform.localScale = Vector3.one * dropBaseScale[i];
                    Color c = drops[i].color; c.a = .95f; drops[i].color = c;
                }
                else
                {
                    float splashT = (travel - height) / .48f;
                    float side = i % 2 == 0 ? -1f : 1f;
                    float arc = Mathf.Sin(splashT * Mathf.PI);
                    drops[i].transform.position = new Vector3(outlet.x + sway + side * splashT * (.13f + i * .015f),
                        surface + .025f + arc * (.18f + (i % 3) * .055f), -.25f);
                    drops[i].transform.localScale = Vector3.one * dropBaseScale[i] * (1f + splashT * .35f);
                    Color c = drops[i].color; c.a = 1f - splashT; drops[i].color = c;
                }
            }
            for (int i = 0; i < splashes.Length; i++)
            {
                float t = Mathf.Repeat(time * .8f + splashPhase[i], 1f);
                float pop = Mathf.Sin(t * Mathf.PI);
                float spread = (i - 1.5f) * (.09f + pop * .07f);
                splashes[i].transform.position = new Vector3(outlet.x + sway + spread,
                    surface + .035f + pop * (.18f + (i % 2) * .12f), -.21f);
                splashes[i].transform.localScale = Vector3.one * splashBaseScale[i] * (1f + pop * 1.8f);
                Color c = splashes[i].color; c.a = 1f - t; splashes[i].color = c;
            }
        }

        public void Dispose()
        {
            if (ribbonMesh != null) UnityEngine.Object.Destroy(ribbonMesh);
        }
    }

    void OnDestroy()
    {
        if (pours != null) for (int i = 0; i < pours.Length; i++) pours[i].Dispose();
        if (surfaceMesh != null) Destroy(surfaceMesh);
        if (surfaceMaterial != null) Destroy(surfaceMaterial);
    }
}

public class LavaPipeFlow : MonoBehaviour
{
    EchoShiftGame game;
    Vector2[] points;
    float[] cumulative;
    float totalLength, speed, offset;
    SpriteRenderer sprite;

    public void Initialize(EchoShiftGame owner, Vector2[] route, float flowSpeed, float phaseOffset)
    {
        game = owner; points = route; speed = flowSpeed; offset = phaseOffset;
        cumulative = new float[points.Length];
        for (int i = 1; i < points.Length; i++)
        {
            totalLength += Vector2.Distance(points[i - 1], points[i]);
            cumulative[i] = totalLength;
        }
        sprite = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (game == null || game.State != EchoShiftGame.GameState.Playing || points == null || totalLength <= 0f) return;
        float distance = Mathf.Repeat(Time.time * speed + offset, totalLength);
        int segment = 0;
        while (segment < cumulative.Length - 2 && distance > cumulative[segment + 1]) segment++;
        float segmentLength = cumulative[segment + 1] - cumulative[segment];
        float t = segmentLength <= .0001f ? 0f : (distance - cumulative[segment]) / segmentLength;
        Vector2 point = Vector2.Lerp(points[segment], points[segment + 1], t);
        transform.position = new Vector3(point.x, point.y, -.08f);
        if (sprite != null)
        {
            Color color = sprite.color; color.a = .58f + .36f * Mathf.Sin(Time.time * 8f + offset); sprite.color = color;
            float size = .14f + .045f * Mathf.Sin(Time.time * 10f + offset);
            transform.localScale = Vector3.one * size;
        }
    }
}

public class ResonanceCore : MonoBehaviour
{
    EchoShiftGame game;
    EchoShiftGame.WorldPhase requiredPhase;
    bool collected;
    float phase;
    SpriteRenderer[] renderers;
    Color[] activeColors;

    public void Initialize(EchoShiftGame owner, EchoShiftGame.WorldPhase phaseNeeded)
    {
        game = owner; requiredPhase = phaseNeeded; phase = Random.Range(0f, 6.28f);
        var trigger = gameObject.AddComponent<CircleCollider2D>(); trigger.isTrigger = true; trigger.radius = .6f;
        var glow = EchoArt.SpriteObject("Resonance halo", transform, transform.position, new Vector3(1.85f, 1.85f, 1), EchoArt.Orb, new Color(.2f, .9f, 1f, .55f), 0);
        var gem = EchoArt.SpriteObject("Resonance crystal", transform, transform.position, new Vector3(.72f, .96f, 1), EchoArt.White, new Color(.62f, 1f, 1f), 2);
        gem.transform.rotation = Quaternion.Euler(0, 0, 45);
        EchoArt.SpriteObject("Crystal glint", transform, transform.position + new Vector3(-.1f, .15f, -.02f), new Vector3(.17f, .32f, 1), EchoArt.White, Color.white, 3);
        EchoArt.SpriteObject("Crystal orbit", transform, transform.position, new Vector3(1.32f, 1.32f, 1), EchoArt.Ring, new Color(.95f, .52f, 1f, .82f), 1);
        renderers = GetComponentsInChildren<SpriteRenderer>(true);
        activeColors = new Color[renderers.Length];
        for (int i = 0; i < renderers.Length; i++) activeColors[i] = renderers[i].color;
        SetPhaseVisibility(game.CurrentPhase);
        gameObject.name = phaseNeeded == EchoShiftGame.WorldPhase.Echo ? "Echo Core" : "Material Core";
    }

    void Update()
    {
        if (collected) return;
        SetPhaseVisibility(game.CurrentPhase);
        float pulse = 1f + Mathf.Sin(Time.time * 3.1f + phase) * .08f;
        transform.localScale = new Vector3(pulse, pulse, 1);
        transform.Rotate(0, 0, 24f * Time.deltaTime);
    }

    void SetPhaseVisibility(EchoShiftGame.WorldPhase current)
    {
        bool active = current == requiredPhase;
        if (renderers == null) return;
        for (int i = 0; i < renderers.Length; i++)
        {
            var renderer = renderers[i];
            if (renderer == null) continue;
            renderer.enabled = true;
            Color color = activeColors[i];
            if (!active)
            {
                Color ghostTint = requiredPhase == EchoShiftGame.WorldPhase.Echo ? new Color(.61f, .46f, 1f) : new Color(.36f, .83f, 1f);
                color = new Color(ghostTint.r, ghostTint.g, ghostTint.b, color.a * .45f);
            }
            renderer.color = color;
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        TryCollect(other, true);
    }

    void OnTriggerStay2D(Collider2D other)
    {
        // If the player shifts phase while already touching the crystal, collect it on the next physics step.
        TryCollect(other, false);
    }

    void TryCollect(Collider2D other, bool showPhaseHint)
    {
        if (collected || other.GetComponent<PlayerController2D>() == null) return;
        if (game.CurrentPhase != requiredPhase)
        {
            if (showPhaseHint)
                game.ShowHint(requiredPhase == EchoShiftGame.WorldPhase.Echo
                    ? "Ten rdzeń wymaga fazy ECHA. Skocz i naciśnij Q w locie."
                    : "Ten rdzeń wymaga fazy MATERII. Skocz i naciśnij Q w locie.");
            return;
        }
        collected = true;
        game.CollectCore(transform.position);
        Destroy(gameObject);
    }
}

public class EchoGoal : MonoBehaviour
{
    EchoShiftGame game;
    SpriteRenderer lamp;
    public void Initialize(EchoShiftGame owner, SpriteRenderer beacon) { game = owner; lamp = beacon; }
    void Update()
    {
        if (lamp != null) lamp.color = game != null && game.HasAllCores ? new Color(.35f, 1f, .78f) : new Color(1f, .45f, .28f);
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController2D>() == null || game == null) return;
        if (game.HasAllCores) game.ReachExit(); else game.ShowHint("Zbierz wszystkie rdzenie rezonansu.");
    }
}

public class EchoBurst : MonoBehaviour
{
    SpriteRenderer sr;
    float age, duration;
    float startSize;
    public void Initialize(Color color, float size = 1.2f, float life = .5f)
    {
        sr = gameObject.AddComponent<SpriteRenderer>(); sr.sprite = EchoArt.Ring; sr.color = color; sr.sortingOrder = 10;
        duration = life; startSize = size; transform.localScale = Vector3.one * (size * .5f);
    }
    void Update()
    {
        age += Time.deltaTime;
        float t = Mathf.Clamp01(age / duration);
        transform.localScale = Vector3.one * Mathf.Lerp(startSize * .5f, startSize * 2f, t);
        if (sr != null) { Color c = sr.color; c.a = 1f - t; sr.color = c; }
        if (age >= duration) Destroy(gameObject);
    }
}
