using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D), typeof(BoxCollider2D))]
public class PlayerController2D : MonoBehaviour
{
    public float moveSpeed = 6.2f;
    public float jumpVelocity = 12.5f;
    public LayerMask groundMask;
    Rigidbody2D body;
    SpriteRenderer sprite;
    Transform groundProbe;
    Transform aura;
    EchoArt.PlayerFrames frames;
    float horizontal;
    float coyoteTimer;
    float jumpBuffer;
    float landingTimer;
    float facing = 1f;
    bool grounded;
    bool echoLook;
    float pulseTimer;
    Transform visualTransform;

    public bool IsGrounded { get { return grounded; } }
    public Vector2 Velocity { get { return body != null ? body.linearVelocity : Vector2.zero; } }

    void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        SpriteRenderer rootSprite = GetComponent<SpriteRenderer>();
        if (rootSprite != null)
        {
            visualTransform = new GameObject("Animated Runner Visual").transform;
            visualTransform.SetParent(transform, false);
            sprite = visualTransform.gameObject.AddComponent<SpriteRenderer>();
            sprite.sprite = rootSprite.sprite; sprite.color = rootSprite.color;
            sprite.sortingLayerID = rootSprite.sortingLayerID; sprite.sortingOrder = rootSprite.sortingOrder;
            rootSprite.enabled = false;
        }
        else
        {
            sprite = GetComponentInChildren<SpriteRenderer>();
            if (sprite != null) visualTransform = sprite.transform;
        }
        frames = EchoArt.Player;
        groundProbe = new GameObject("Ground Probe").transform;
        groundProbe.SetParent(transform, false); groundProbe.localPosition = new Vector3(0, .055f, 0);
        var auraGo = new GameObject("Phase Aura"); auraGo.transform.SetParent(transform, false); auraGo.transform.localPosition = new Vector3(0, .72f, .1f);
        aura = auraGo.transform;
        var auraSr = auraGo.AddComponent<SpriteRenderer>(); auraSr.sprite = EchoArt.Ring; auraSr.color = new Color(.2f, .9f, 1f, .3f); auraSr.sortingOrder = -1;
        aura.localScale = new Vector3(.55f, .55f, 1);
    }

    void Update()
    {
        Keyboard keyboard = Keyboard.current;
        horizontal = 0;
        if (keyboard != null)
        {
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) horizontal -= 1;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) horizontal += 1;
            if (keyboard.spaceKey.wasPressedThisFrame || keyboard.upArrowKey.wasPressedThisFrame || keyboard.wKey.wasPressedThisFrame) jumpBuffer = .14f;
        }
        jumpBuffer -= Time.deltaTime;
        pulseTimer = Mathf.Max(0, pulseTimer - Time.deltaTime);
        landingTimer = Mathf.Max(0, landingTimer - Time.deltaTime);
        if (grounded) coyoteTimer = .12f; else coyoteTimer -= Time.deltaTime;
        Animate();
        if (aura != null)
        {
            float pulse = 1f + Mathf.Sin(Time.time * 3.4f) * .06f + (pulseTimer > 0 ? pulseTimer * .2f : 0);
            aura.localScale = Vector3.one * (.55f * pulse);
        }
    }

    void FixedUpdate()
    {
        Collider2D supportCollider = Physics2D.OverlapBox(groundProbe.position, new Vector2(.48f, .14f), 0, groundMask);
        bool touchingGround = supportCollider != null && body.linearVelocity.y <= .05f;
        if (!touchingGround) supportCollider = null;
        float platformVelocityX = 0f;
        if (supportCollider != null)
        {
            PhasePlatform movingPlatform = supportCollider.GetComponent<PhasePlatform>();
            if (movingPlatform != null) platformVelocityX = movingPlatform.Velocity.x;
        }
        if (!grounded && touchingGround) landingTimer = .18f;
        grounded = touchingGround;
        var v = body.linearVelocity;
        v.x = horizontal * moveSpeed + platformVelocityX;
        if (jumpBuffer > 0 && coyoteTimer > 0)
        {
            v.y = jumpVelocity;
            jumpBuffer = 0; coyoteTimer = 0; grounded = false;
            EchoShiftGame.Instance?.PlayJumpSound();
        }
        Keyboard keyboard = Keyboard.current;
        bool jumpHeld = keyboard != null && (keyboard.spaceKey.isPressed || keyboard.upArrowKey.isPressed || keyboard.wKey.isPressed);
        if (jumpHeld && v.y > 0)
            v.y += 5f * Time.fixedDeltaTime;
        body.linearVelocity = v;
    }

    void Animate()
    {
        if (sprite == null || frames == null || visualTransform == null) return;
        float vy = body != null ? body.linearVelocity.y : 0;
        if (!grounded) sprite.sprite = vy > .3f ? frames.jump : frames.fall;
        else if (Mathf.Abs(horizontal) > .05f) sprite.sprite = frames.run[Mathf.FloorToInt(Time.time * 10f) % frames.run.Length];
        else sprite.sprite = frames.idle[Mathf.FloorToInt(Time.time * 2.5f) % frames.idle.Length];
        if (Mathf.Abs(horizontal) > .05f) facing = Mathf.Sign(horizontal);
        float scaleX = 1f, scaleY = 1f, bob = 0f, tilt = 0f;
        if (landingTimer > 0)
        {
            float squash = Mathf.Sin((landingTimer / .18f) * Mathf.PI);
            scaleX += .13f * squash; scaleY -= .18f * squash;
        }
        else if (!grounded)
        {
            scaleX = vy > .3f ? .93f : 1.04f;
            scaleY = vy > .3f ? 1.1f : .94f;
            tilt = Mathf.Clamp(-body.linearVelocity.x * 1.25f, -10f, 10f);
        }
        else if (Mathf.Abs(horizontal) > .05f)
        {
            float stride = Mathf.Sin(Time.time * 19f);
            scaleX = 1f + .035f * stride; scaleY = 1f - .045f * stride;
            bob = Mathf.Abs(stride) * .035f; tilt = -facing * 3f;
        }
        else
        {
            float breathe = Mathf.Sin(Time.time * 3f);
            scaleX = 1f - .012f * breathe; scaleY = 1f + .018f * breathe;
            bob = Mathf.Sin(Time.time * 2.5f) * .025f;
        }
        visualTransform.localScale = new Vector3(facing * scaleX, scaleY, 1f);
        visualTransform.localPosition = new Vector3(0f, bob, 0f);
        visualTransform.localRotation = Quaternion.Euler(0f, 0f, tilt);
        if (echoLook) sprite.color = Color.Lerp(Color.white, new Color(.45f, 1f, 1f), .35f);
        else sprite.color = Color.white;
    }

    public void SetEchoLook(bool enabled) { echoLook = enabled; pulseTimer = .55f; }
    public void DisableMotion() { if (body != null) { body.linearVelocity = Vector2.zero; body.simulated = false; } }
}
