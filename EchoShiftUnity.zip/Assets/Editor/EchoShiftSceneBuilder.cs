using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

[InitializeOnLoad]
static class EchoShiftAutoSetup
{
    static EchoShiftAutoSetup()
    {
        EditorApplication.delayCall += () =>
        {
            if (!File.Exists("Assets/Scenes/EchoShift.unity")) EchoShiftSceneBuilder.CreateDemoScene();
        };
    }
}

public static class EchoShiftSceneBuilder
{
    const string ScenePath = "Assets/Scenes/EchoShift.unity";

    [MenuItem("Echo Shift/Create Demo Scene")]
    public static void CreateDemoScene()
    {
        Directory.CreateDirectory("Assets/Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var cameraObject = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener), typeof(EchoShiftGame));
        cameraObject.tag = "MainCamera";
        cameraObject.transform.position = new Vector3(0, 5.3f, -10);
        var camera = cameraObject.GetComponent<Camera>();
        camera.orthographic = true; camera.orthographicSize = 5.3f;
        camera.clearFlags = CameraClearFlags.SolidColor;
        camera.backgroundColor = new Color(.018f, .026f, .06f);
        camera.nearClipPlane = .1f; camera.farClipPlane = 100;
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("Echo Shift scene created at " + ScenePath);
    }
}
